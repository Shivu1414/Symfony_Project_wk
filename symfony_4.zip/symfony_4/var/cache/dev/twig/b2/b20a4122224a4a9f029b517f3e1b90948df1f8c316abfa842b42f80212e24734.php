<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* view/aRegistration.html.twig */
class __TwigTemplate_421b0d01f4d2b55c2447f938b896d2a170375fc83f0943d519bc2938c8c2cd8d extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'javascripts' => [$this, 'block_javascripts'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "view/aRegistration.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "view/aRegistration.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "view/aRegistration.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 2
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "Login Form";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 3
    public function block_javascripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        // line 4
        echo "            ";
        // line 5
        echo "            <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js\"></script>
            <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js\"></script>
            <script src=\"https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js\"></script>
            <script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js\"></script>
            <script src=\"https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js\" integrity=\"sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL\" crossorigin=\"anonymous\"></script>
            <script src=\"";
        // line 10
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/aRegistration.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 12
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 13
        echo "
<link href=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("css/aRegistration.css"), "html", null, true);
        echo "\" rel=\"stylesheet\"/>
<link href=\"";
        // line 15
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("css/common.css"), "html", null, true);
        echo "\" rel=\"stylesheet\"/>


 <div class=\"navbar p-0\" onload=\"generate()\">
    <div class=\"left\">
        <img src=\"";
        // line 20
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/navimg.png"), "html", null, true);
        echo "\" alt=\"Not mentioned\" class=\"navimg\"/>
        <div class=\"left-div\">
        <span class=\"left-txt\">Webkul</span>
        </div>
    </div>

    <div class=\"right\">
    <a href=\"";
        // line 27
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("signup");
        echo "\">
    <input type=\"submit\" class=\"user\" value=\"User Registration\">
    </a>
    <a href=\"";
        // line 30
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("login");
        echo "\">
    <input type=\"submit\" class=\"user admin\" value=\"Login\">
    </a>
    </div>
 </div>


        <div class=\"div2 p-3\">
            <div class=\"child3\">
                <h3 class=\"head1\">Admin Registration Form</h3>
            </div>
            <p><span class=\"error req-fd\">* required field</span></p>
            <form method=\"post\" action=\"";
        // line 42
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_signdata");
        echo "\" onsubmit=\"return cnfLogin()\">
                <div class=\"form-content\">
                    <span class=\"para1\">User Name:</span>
                    <span class=\"error req-fd\" id=\"nameHint\">*
                    </span>
                    <span id=\"okname\" class=\"status ok-g hcn\"><i class=\"fa-regular fa-circle-check\"></i></span>
                    <span id=\"unokname\" class=\"status unok-r hcn\"><i class=\"fa-regular fa-circle-xmark\"></i></span>
                    <span id=\"hintn\" class=\"hint-css\"></span>
                    <br><input type=\"text\" name=\"name\" value=\"\" class=\"inp\" id=\"nameVal\">
                    <br>
                </div>


                <div class=\"form-content\">
                    <span class=\"para1\">E-mail:</span>
                    <span class=\"error req-fd\" id=\"mailErr\">*
                    </span>
                    <span id=\"okmail\" class=\"status ok-g hcm\"><i class=\"fa-regular fa-circle-check\"></i></span>
                    <span id=\"unokmail\" class=\"status unok-r hcm\"><i class=\"fa-regular fa-circle-xmark\"></i></span>
                    <span id=\"hintm\" class=\"hint-css\"></span>
                    <br><input type=\"text\" name=\"email\" value=\"\" class=\"inp\" id=\"emailVal\">
                    <br>
                </div>



                <div class=\"form-content\">
                    <span class=\"para1\">Password:</span>
                    <span class=\"error req-fd\">*
                    </span>
                    <span id=\"okpass\" class=\"status ok-g hcp\"><i class=\"fa-regular fa-circle-check\"></i></span>
                    <span id=\"unokpass\" class=\"status unok-r hcp\"><i class=\"fa-regular fa-circle-xmark\"></i></span>
                    <span id=\"hintpass\" class=\"hint-css-p\"></span>
                    <br><input type=\"password\" name=\"pass1\" value=\"\" class=\"inp\" id=\"passVal\">
                    <br>
                </div>



                <div class=\"form-content\">
                    <span class=\"para1\">Confirm Password:</span>
                    <span class=\"error req-fd\">*
                    </span>
                    <span id=\"okpasscnf\" class=\"status ok-g hcpc\"><i class=\"fa-regular fa-circle-check\"></i></span>
                    <span id=\"unokpasscnf\" class=\"status unok-r hcpc\"><i class=\"fa-regular fa-circle-xmark\"></i></span>
                    <span id=\"hintpasscnf\" class=\"hint-css-p\"></span>
                    <br><input type=\"password\" name=\"pass2\" value=\"\" class=\"inp\" id=\"passCnfVal\">
                    <br>
                </div>

                <div class=\"form-content captcha-div\">
                    <div class=\"e-captcha\">
                        <label for=\"\" class=\"c-lable\">Enter Captcha:</label>
                        <span class=\"error req-fd\">*</span>
                        <span id=\"okcaptcha\" class=\"status ok-g hcc\"><i class=\"fa-regular fa-circle-check\"></i></span>
                        <span id=\"unokcaptcha\" class=\"status unok-r hcc\"><i class=\"fa-regular fa-circle-xmark\"></i></span>
                        <span id=\"hintcaptcha\" class=\"hint-captcha\"></span>
                        <input type=\"text\" id=\"captch\" class=\"c-code\">
                    </div>

                    <div class=\"inline reboot\" onclick=\"generate()\" id=\"hc\">
                        <br>
                        <i class=\"fa-solid fa-rotate-right logo\"></i>
                    </div>

                    <div id=\"cImg\" class=\"inline i-captcha\" selectable=\"False\">
                        <label for=\"\" class=\"c-lable\">Captcha Code:</label><br>
                        <p class=\"i-rnd\"><del><span id=\"random\"></span></del></p>
                    </div>
                </div>

                <div class=\"form-content\">
                    <input type=\"checkbox\" name=\"\" value=\" \" class=\"check-box-term\" id = \"checkbox\">
                    <label for=\"\">I accept the Terms and Conditions.</label>
                    <span class=\"error req-fd\">*</span>
                        <span id=\"okcb\" class=\"status ok-g hcb\"><i class=\"fa-regular fa-circle-check\"></i></span>
                        <span id=\"unokcb\" class=\"status unok-r hcb\"><i class=\"fa-regular fa-circle-xmark\"></i></span>
                        <span id=\"hintcb\" class=\"hint-css-p\"></span>
                </div>

                <div class=\"form-content\">
                    <input type=\"submit\" name=\"submit\" value=\"REGISTER NOW\" class=\"preview\" id=\"sbt\" onmouseover=\"hoverbtn()\">
                </div>
            </form>
        </div>
    </div>


<div class=\"container-fluid p-0 footer-div\">

<footer class=\"bg-dark text-center text-white pt-5\">
  <div class=\"container p-4 pb-0\">
    <section class=\"mb-4\">
      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-facebook-f\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-twitter\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-google\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-instagram\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-linkedin-in\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-github\"></i></a>
    </section>
  </div>

  <div class=\"text-center p-3\" style=\"background-color: rgba(0, 0, 0, 0.2);\">
    © 2020 Copyright:
    <a class=\"text-white\" href=\"https://webkul.com/\">Webkul.com</a>
  </div>
</footer>
  
</div>

<script> 
</script>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "view/aRegistration.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable()
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  166 => 42,  151 => 30,  145 => 27,  135 => 20,  127 => 15,  123 => 14,  120 => 13,  110 => 12,  98 => 10,  91 => 5,  89 => 4,  79 => 3,  60 => 2,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}
{% block title %}Login Form{% endblock %}
{% block javascripts %}
            {#{{ encore_entry_script_tags('app') }}#}
            <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js\"></script>
            <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js\"></script>
            <script src=\"https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js\"></script>
            <script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js\"></script>
            <script src=\"https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js\" integrity=\"sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL\" crossorigin=\"anonymous\"></script>
            <script src=\"{{ asset('js/aRegistration.js') }}\"></script>
{% endblock %}
{% block body %}

<link href=\"{{ asset('css/aRegistration.css') }}\" rel=\"stylesheet\"/>
<link href=\"{{asset('css/common.css')}}\" rel=\"stylesheet\"/>


 <div class=\"navbar p-0\" onload=\"generate()\">
    <div class=\"left\">
        <img src=\"{{ asset('img/navimg.png') }}\" alt=\"Not mentioned\" class=\"navimg\"/>
        <div class=\"left-div\">
        <span class=\"left-txt\">Webkul</span>
        </div>
    </div>

    <div class=\"right\">
    <a href=\"{{path('signup')}}\">
    <input type=\"submit\" class=\"user\" value=\"User Registration\">
    </a>
    <a href=\"{{path('login')}}\">
    <input type=\"submit\" class=\"user admin\" value=\"Login\">
    </a>
    </div>
 </div>


        <div class=\"div2 p-3\">
            <div class=\"child3\">
                <h3 class=\"head1\">Admin Registration Form</h3>
            </div>
            <p><span class=\"error req-fd\">* required field</span></p>
            <form method=\"post\" action=\"{{path('admin_signdata')}}\" onsubmit=\"return cnfLogin()\">
                <div class=\"form-content\">
                    <span class=\"para1\">User Name:</span>
                    <span class=\"error req-fd\" id=\"nameHint\">*
                    </span>
                    <span id=\"okname\" class=\"status ok-g hcn\"><i class=\"fa-regular fa-circle-check\"></i></span>
                    <span id=\"unokname\" class=\"status unok-r hcn\"><i class=\"fa-regular fa-circle-xmark\"></i></span>
                    <span id=\"hintn\" class=\"hint-css\"></span>
                    <br><input type=\"text\" name=\"name\" value=\"\" class=\"inp\" id=\"nameVal\">
                    <br>
                </div>


                <div class=\"form-content\">
                    <span class=\"para1\">E-mail:</span>
                    <span class=\"error req-fd\" id=\"mailErr\">*
                    </span>
                    <span id=\"okmail\" class=\"status ok-g hcm\"><i class=\"fa-regular fa-circle-check\"></i></span>
                    <span id=\"unokmail\" class=\"status unok-r hcm\"><i class=\"fa-regular fa-circle-xmark\"></i></span>
                    <span id=\"hintm\" class=\"hint-css\"></span>
                    <br><input type=\"text\" name=\"email\" value=\"\" class=\"inp\" id=\"emailVal\">
                    <br>
                </div>



                <div class=\"form-content\">
                    <span class=\"para1\">Password:</span>
                    <span class=\"error req-fd\">*
                    </span>
                    <span id=\"okpass\" class=\"status ok-g hcp\"><i class=\"fa-regular fa-circle-check\"></i></span>
                    <span id=\"unokpass\" class=\"status unok-r hcp\"><i class=\"fa-regular fa-circle-xmark\"></i></span>
                    <span id=\"hintpass\" class=\"hint-css-p\"></span>
                    <br><input type=\"password\" name=\"pass1\" value=\"\" class=\"inp\" id=\"passVal\">
                    <br>
                </div>



                <div class=\"form-content\">
                    <span class=\"para1\">Confirm Password:</span>
                    <span class=\"error req-fd\">*
                    </span>
                    <span id=\"okpasscnf\" class=\"status ok-g hcpc\"><i class=\"fa-regular fa-circle-check\"></i></span>
                    <span id=\"unokpasscnf\" class=\"status unok-r hcpc\"><i class=\"fa-regular fa-circle-xmark\"></i></span>
                    <span id=\"hintpasscnf\" class=\"hint-css-p\"></span>
                    <br><input type=\"password\" name=\"pass2\" value=\"\" class=\"inp\" id=\"passCnfVal\">
                    <br>
                </div>

                <div class=\"form-content captcha-div\">
                    <div class=\"e-captcha\">
                        <label for=\"\" class=\"c-lable\">Enter Captcha:</label>
                        <span class=\"error req-fd\">*</span>
                        <span id=\"okcaptcha\" class=\"status ok-g hcc\"><i class=\"fa-regular fa-circle-check\"></i></span>
                        <span id=\"unokcaptcha\" class=\"status unok-r hcc\"><i class=\"fa-regular fa-circle-xmark\"></i></span>
                        <span id=\"hintcaptcha\" class=\"hint-captcha\"></span>
                        <input type=\"text\" id=\"captch\" class=\"c-code\">
                    </div>

                    <div class=\"inline reboot\" onclick=\"generate()\" id=\"hc\">
                        <br>
                        <i class=\"fa-solid fa-rotate-right logo\"></i>
                    </div>

                    <div id=\"cImg\" class=\"inline i-captcha\" selectable=\"False\">
                        <label for=\"\" class=\"c-lable\">Captcha Code:</label><br>
                        <p class=\"i-rnd\"><del><span id=\"random\"></span></del></p>
                    </div>
                </div>

                <div class=\"form-content\">
                    <input type=\"checkbox\" name=\"\" value=\" \" class=\"check-box-term\" id = \"checkbox\">
                    <label for=\"\">I accept the Terms and Conditions.</label>
                    <span class=\"error req-fd\">*</span>
                        <span id=\"okcb\" class=\"status ok-g hcb\"><i class=\"fa-regular fa-circle-check\"></i></span>
                        <span id=\"unokcb\" class=\"status unok-r hcb\"><i class=\"fa-regular fa-circle-xmark\"></i></span>
                        <span id=\"hintcb\" class=\"hint-css-p\"></span>
                </div>

                <div class=\"form-content\">
                    <input type=\"submit\" name=\"submit\" value=\"REGISTER NOW\" class=\"preview\" id=\"sbt\" onmouseover=\"hoverbtn()\">
                </div>
            </form>
        </div>
    </div>


<div class=\"container-fluid p-0 footer-div\">

<footer class=\"bg-dark text-center text-white pt-5\">
  <div class=\"container p-4 pb-0\">
    <section class=\"mb-4\">
      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-facebook-f\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-twitter\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-google\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-instagram\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-linkedin-in\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-github\"></i></a>
    </section>
  </div>

  <div class=\"text-center p-3\" style=\"background-color: rgba(0, 0, 0, 0.2);\">
    © 2020 Copyright:
    <a class=\"text-white\" href=\"https://webkul.com/\">Webkul.com</a>
  </div>
</footer>
  
</div>

<script> 
</script>

{% endblock %}", "view/aRegistration.html.twig", "/home/users/shivam.baranwal/www/html/symfony_4/templates/view/aRegistration.html.twig");
    }
}
