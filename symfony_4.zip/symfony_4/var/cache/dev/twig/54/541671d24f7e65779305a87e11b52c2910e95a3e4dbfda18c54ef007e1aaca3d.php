<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* view/uRegistration.html.twig */
class __TwigTemplate_f4461824ee60a333fd1a417261fc6e90456ba5c8c15ff340762073f9e2473064 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'javascripts' => [$this, 'block_javascripts'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "view/uRegistration.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "view/uRegistration.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "view/uRegistration.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 2
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "Login Form";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 3
    public function block_javascripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        // line 4
        echo "            ";
        // line 5
        echo "            <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js\"></script>
            <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js\"></script>
            <script src=\"https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js\"></script>
            <script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js\"></script>
            <script src=\"https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js\" integrity=\"sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL\" crossorigin=\"anonymous\"></script>
            <script src=\"";
        // line 10
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/uRegistration.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 13
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 14
        echo "
<link href=\"";
        // line 15
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("css/uRegistration.css"), "html", null, true);
        echo "\" rel=\"stylesheet\"/>
<link href=\"";
        // line 16
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("css/common.css"), "html", null, true);
        echo "\" rel=\"stylesheet\"/>

<div class=\"navbar p-0\" onload=\"generate()\">
    <div class=\"left\">
        <img src=\"";
        // line 20
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/navimg.png"), "html", null, true);
        echo "\" alt=\"Not mentioned\" class=\"navimg\"/>
        <div class=\"left-div\">
        <span class=\"left-txt\">Webkul</span>
        </div>
    </div>

    <div class=\"right\">
    <a href=\"";
        // line 27
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("login");
        echo "\">
    <input type=\"submit\" class=\"user\" value=\"Login\">
    </a>
    <a href=\"";
        // line 30
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin");
        echo "\">
    <input type=\"submit\" class=\"user admin\" value=\"Admin Registration\">
    </a>
    </div>
 </div>


         <div class=\"div2 p-3\">
            <div class=\"child3\">
                <h3 class=\"head1\">User Registration Form</h3>
            </div>
            <p><span class=\"error req-fd\">* required field</span></p>
            <form method=\"post\" action=\"";
        // line 42
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("signdata");
        echo "\" enctype=\"multipart/form-data\" onsubmit=\"return cnfRegister()\"  >
                <div class=\"form-content\">
                    <span class=\"para1\">First Name:</span>
                    <span class=\"error req-fd\" id=\"nameHint\">*</span>
                    <span id=\"okname\" class=\"status ok-g hcn\"><i class=\"fa-regular fa-circle-check\"></i></span>
                    <span id=\"unokname\" class=\"status unok-r hcn\"><i class=\"fa-regular fa-circle-xmark\"></i></span>
                    <span id=\"hintn\" class=\"hint-css\"></span>
                    <br><input type=\"text\" name=\"name\" value=\"\" class=\"inp\" id=\"nameVal\">
                    <br>
                </div>


                <div class=\"form-content\">
                    <span class=\"para1\">Last Name:</span>
                    <span class=\"error req-fd\" id=\"namelHint\">*</span>
                    <span id=\"oklname\" class=\"status ok-g hcln\"><i class=\"fa-regular fa-circle-check\"></i></span>
                    <span id=\"unoklname\" class=\"status unok-r hcln\"><i class=\"fa-regular fa-circle-xmark\"></i></span>
                    <span id=\"hintln\" class=\"hint-css\"></span>
                    <br><input type=\"text\" name=\"lname\" value=\"\" class=\"inp\" id=\"lnameVal\">
                    <br>
                </div>


                <div class=\"form-content\">
                    <span class=\"para1\">E-mail:</span>
                    <span class=\"error req-fd\" id=\"emailHint\">*
                    </span>
                    <span id=\"okmail\" class=\"status ok-g hcm\"><i class=\"fa-regular fa-circle-check\"></i></span>
                    <span id=\"unokmail\" class=\"status unok-r hcm\"><i class=\"fa-regular fa-circle-xmark\"></i></span>
                    <span id=\"hintm\" class=\"hint-css\"></span>
                    <br><input type=\"text\" name=\"email\" value=\"\" class=\"inp\" id=\"emailVal\">
                    <br>
                </div>

                <div class=\"form-content\">
                    <span class=\"para1\">Phone No:</span>
                    <span class=\"error req-fd\" id=\"phnHint\">*
                    </span>
                    <span id=\"okphn\" class=\"status ok-g hcph\"><i class=\"fa-regular fa-circle-check\"></i></span>
                    <span id=\"unokphn\" class=\"status unok-r hcph\"><i class=\"fa-regular fa-circle-xmark\"></i></span>
                    <span id=\"hintphn\" class=\"hint-css\"></span>
                    <br><input type=\"tel\" class=\"inp\" name=\"phone\" id=\"phnVal\" placeholder=\"Ex: 6974512311\">
                    <br>
                </div>
     

                <div class=\"form-content mt-4 mb-4\">
                    <span class=\"para1\">Gender:</span>
                    <input type=\"radio\" name=\"gender\" value=\"female\" id=\"gen\" class=\"gendr\">
                    <span class=\"para1\">Female</span>   
                    <input type=\"radio\" name=\"gender\" value=\"male\" id=\"gen\" class=\"gendr\">
                    <span class=\"para1\">Male</span>   
                    <input type=\"radio\" name=\"gender\" value=\"other\" id=\"gen\" class=\"gendr\">
                    <span class=\"para1\">Other</span>                   
                    <span id=\"\" class=\"error req-fd\">*</span>
                    <span id=\"okgender\" class=\"status ok-g hg\"><i class=\"fa-regular fa-circle-check\"></i></span>
                    <span id=\"unokgender\" class=\"status unok-r hg\"><i class=\"fa-regular fa-circle-xmark\"></i></span>
                    <span id=\"hintgender\" class=\"hint-css-p\"></span>
                </div>
                

                <div class=\"form-content\">
                <span class=\"para1\" >About Yourself:</span> 
                <span class=\"error req-fd\" id=\"titleHint\">*</span>
                <span id=\"okabout\" class=\"status ok-g habt\"><i class=\"fa-regular fa-circle-check\"></i></span>
                <span id=\"unokabout\" class=\"status unok-r habt\"><i class=\"fa-regular fa-circle-xmark\"></i></span>
                <span id=\"hintabout\" class=\"hint-css-p\"></span>
                <br><textarea name=\"about\" rows=\"3\" cols=\"40\" class=\"inp1\" id=\"habout\"></textarea>
                <br>
               </div>

               <div class=\"form-content\">
                <span class=\"para1\" >Address:</span> 
                <span class=\"error req-fd\" id=\"titleHint\">*</span>
                <span id=\"okadd\" class=\"status ok-g hadd\"><i class=\"fa-regular fa-circle-check\"></i></span>
                <span id=\"unokadd\" class=\"status unok-r hadd\"><i class=\"fa-regular fa-circle-xmark\"></i></span>
                <span id=\"hintadd\" class=\"hint-css-p\"></span>
                <br><textarea name=\"address\" rows=\"3\" cols=\"40\" class=\"inp1\" id=\"haddress\"></textarea>
                <br>
               </div>

               <div class=\"form-content\" >
                    <div class=\"select_option\" >
                    <select name=\"country\" class=\"form-select country inp1\" aria-label=\"Default select example\" onchange=\"return loadStates()\">
                        <option selected>Select Country</option>
                    </select>
                    <div class=\"select_option \">
                    <select name=\"state\" class=\"form-select state inp1 \" aria-label=\"Default select example\" onchange=\"loadCities()\">
                        <option selected>Select State</option>
                    </select>
                    <select name=\"city\" class=\"form-select city inp1\" aria-label=\"Default select example\">
                        <option selected>Select City</option>
                    </select>
                    </div>
                </div>



               <div class=\"form-content\">
                    <span class=\"para1\">Pin Code:</span>
                    <span class=\"error req-fd\" id=\"pinHint\">*</span>
                    <span id=\"okpin\" class=\"status ok-g hpin\"><i class=\"fa-regular fa-circle-check\"></i></span>
                    <span id=\"unokpin\" class=\"status unok-r hpin\"><i class=\"fa-regular fa-circle-xmark\"></i></span>
                    <span id=\"hintpin\" class=\"hint-css\"></span>
                    <br><input type=\"tel\" class=\"inp\" name=\"pincode\" id=\"pinVal\" placeholder=\"Ex: 276304\">
                    <br>
                </div>

                <div class=\"form-content\">
                    <span class=\"para1\">Password:</span>
                    <span class=\"error req-fd\">*
                    </span>
                    <span id=\"okpass\" class=\"status ok-g hcp\"><i class=\"fa-regular fa-circle-check\"></i></span>
                    <span id=\"unokpass\" class=\"status unok-r hcp\"><i class=\"fa-regular fa-circle-xmark\"></i></span>
                    <span id=\"hintpass\" class=\"hint-css-p\"></span>
                    <br><input type=\"password\" name=\"pass1\" value=\"\" class=\"inp\" id=\"passVal\">
                    <br>
                </div>

                <div class=\"form-content\">
                    <span class=\"para1\">Confirm Password:</span>
                    <span class=\"error req-fd\">*
                    </span>
                    <span id=\"okpasscnf\" class=\"status ok-g hcpc\"><i class=\"fa-regular fa-circle-check\"></i></span>
                    <span id=\"unokpasscnf\" class=\"status unok-r hcpc\"><i class=\"fa-regular fa-circle-xmark\"></i></span>
                    <span id=\"hintpasscnf\" class=\"hint-css-p\"></span>
                    <br><input type=\"password\" name=\"pass2\" value=\"\" class=\"inp\" id=\"passCnfVal\">
                    <br><br>
                </div>

                <div class=\"form-content mt-0\">
                <span class=\"error req-fd img-content\" id=\"imgHint\">*IMG Size less than 1MB and Ext: jpg, png, jpeg </span>
                    <label for=\"fileToUpload\" class=\"up-img\">Upload Image</label>
                         <input type=\"file\" name=\"fileToUpload\" id=\"fileToUpload\" value=\"\" class=\"upload-img bg-success\" >   
                         <span id=\"okimg\" class=\"status ok-g himg\"><i class=\"fa-regular fa-circle-check\"></i></span>
                         <span id=\"unokimg\" class=\"status unok-r himg\"><i class=\"fa-regular fa-circle-xmark\"></i></span>
                         <span id=\"hintimg\" class=\"hint-css-p\"></span>       
                </div>

                <div class=\"form-content captcha-div\">
                    <div class=\"e-captcha\" >
                        <label for=\"\" class=\"c-lable\">Enter Captcha:</label>
                        <span id=\"okcaptcha\" class=\"status ok-g hcc\"><i class=\"fa-regular fa-circle-check\"></i></span>
                        <span id=\"unokcaptcha\" class=\"status unok-r hcc\"><i class=\"fa-regular fa-circle-xmark\"></i></span>
                        <span id=\"hintcaptcha\" class=\"hint-captcha\"></span>
                        <input type=\"text\" id=\"captch\" class=\"c-code\">
                    </div>

                    <div class=\"inline reboot\" onclick=\"generate()\" id=\"hc\">
                        <br>
                        <i class=\"fa-solid fa-rotate-right logo\"></i>
                    </div>

                    <div id=\"cImg\" class=\"inline i-captcha\" selectable=\"False\">
                        <label for=\"\" class=\"c-lable\">Captcha Code:</label><br>
                        <p class=\"i-rnd\"><del><span id=\"random\"></span></del></p>
                    </div>
                </div>  
                
                <div class=\"form-content\">
                    <input type=\"checkbox\" name=\"\" value=\" \" class=\"check-box-term\" id = \"checkbox\">
                    <label for=\"\">I accept the Terms and Conditions.</label>
                    <span class=\"error req-fd\">*</span>
                        <span id=\"okcb\" class=\"status ok-g hcb\"><i class=\"fa-regular fa-circle-check\"></i></span>
                        <span id=\"unokcb\" class=\"status unok-r hcb\"><i class=\"fa-regular fa-circle-xmark\"></i></span>
                        <span id=\"hintcb\" class=\"hint-css-p\"></span>
                </div>

                <div class=\"form-content\">
                    <input type=\"submit\" name=\"submit\" value=\"REGISTER NOW\" class=\"preview\" id=\"sbt\" onmouseover=\"hoverbtn()\">
                </div>
            </form>
        </div>
    </div>


<div class=\"container-fluid p-0 footer-div\">

<footer class=\"bg-dark text-center text-white pt-5\">
  <div class=\"container p-4 pb-0\">
    <section class=\"mb-4\">
      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-facebook-f\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-twitter\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-google\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-instagram\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-linkedin-in\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-github\"></i></a>
    </section>
  </div>

  <div class=\"text-center p-3\" style=\"background-color: rgba(0, 0, 0, 0.2);\">
    © 2020 Copyright:
    <a class=\"text-white\" href=\"https://webkul.com/\">Webkul.com</a>
  </div>
</footer>
  
</div>


<script src=\"";
        // line 246
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/dropdown.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "view/uRegistration.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable()
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  372 => 246,  165 => 42,  150 => 30,  144 => 27,  134 => 20,  127 => 16,  123 => 15,  120 => 14,  110 => 13,  98 => 10,  91 => 5,  89 => 4,  79 => 3,  60 => 2,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}
{% block title %}Login Form{% endblock %}
{% block javascripts %}
            {#{{ encore_entry_script_tags('app') }}#}
            <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js\"></script>
            <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js\"></script>
            <script src=\"https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js\"></script>
            <script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js\"></script>
            <script src=\"https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js\" integrity=\"sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL\" crossorigin=\"anonymous\"></script>
            <script src=\"{{ asset('js/uRegistration.js') }}\"></script>
{% endblock %}

{% block body %}

<link href=\"{{ asset('css/uRegistration.css') }}\" rel=\"stylesheet\"/>
<link href=\"{{asset('css/common.css')}}\" rel=\"stylesheet\"/>

<div class=\"navbar p-0\" onload=\"generate()\">
    <div class=\"left\">
        <img src=\"{{ asset('img/navimg.png') }}\" alt=\"Not mentioned\" class=\"navimg\"/>
        <div class=\"left-div\">
        <span class=\"left-txt\">Webkul</span>
        </div>
    </div>

    <div class=\"right\">
    <a href=\"{{path('login')}}\">
    <input type=\"submit\" class=\"user\" value=\"Login\">
    </a>
    <a href=\"{{path('admin')}}\">
    <input type=\"submit\" class=\"user admin\" value=\"Admin Registration\">
    </a>
    </div>
 </div>


         <div class=\"div2 p-3\">
            <div class=\"child3\">
                <h3 class=\"head1\">User Registration Form</h3>
            </div>
            <p><span class=\"error req-fd\">* required field</span></p>
            <form method=\"post\" action=\"{{path('signdata')}}\" enctype=\"multipart/form-data\" onsubmit=\"return cnfRegister()\"  >
                <div class=\"form-content\">
                    <span class=\"para1\">First Name:</span>
                    <span class=\"error req-fd\" id=\"nameHint\">*</span>
                    <span id=\"okname\" class=\"status ok-g hcn\"><i class=\"fa-regular fa-circle-check\"></i></span>
                    <span id=\"unokname\" class=\"status unok-r hcn\"><i class=\"fa-regular fa-circle-xmark\"></i></span>
                    <span id=\"hintn\" class=\"hint-css\"></span>
                    <br><input type=\"text\" name=\"name\" value=\"\" class=\"inp\" id=\"nameVal\">
                    <br>
                </div>


                <div class=\"form-content\">
                    <span class=\"para1\">Last Name:</span>
                    <span class=\"error req-fd\" id=\"namelHint\">*</span>
                    <span id=\"oklname\" class=\"status ok-g hcln\"><i class=\"fa-regular fa-circle-check\"></i></span>
                    <span id=\"unoklname\" class=\"status unok-r hcln\"><i class=\"fa-regular fa-circle-xmark\"></i></span>
                    <span id=\"hintln\" class=\"hint-css\"></span>
                    <br><input type=\"text\" name=\"lname\" value=\"\" class=\"inp\" id=\"lnameVal\">
                    <br>
                </div>


                <div class=\"form-content\">
                    <span class=\"para1\">E-mail:</span>
                    <span class=\"error req-fd\" id=\"emailHint\">*
                    </span>
                    <span id=\"okmail\" class=\"status ok-g hcm\"><i class=\"fa-regular fa-circle-check\"></i></span>
                    <span id=\"unokmail\" class=\"status unok-r hcm\"><i class=\"fa-regular fa-circle-xmark\"></i></span>
                    <span id=\"hintm\" class=\"hint-css\"></span>
                    <br><input type=\"text\" name=\"email\" value=\"\" class=\"inp\" id=\"emailVal\">
                    <br>
                </div>

                <div class=\"form-content\">
                    <span class=\"para1\">Phone No:</span>
                    <span class=\"error req-fd\" id=\"phnHint\">*
                    </span>
                    <span id=\"okphn\" class=\"status ok-g hcph\"><i class=\"fa-regular fa-circle-check\"></i></span>
                    <span id=\"unokphn\" class=\"status unok-r hcph\"><i class=\"fa-regular fa-circle-xmark\"></i></span>
                    <span id=\"hintphn\" class=\"hint-css\"></span>
                    <br><input type=\"tel\" class=\"inp\" name=\"phone\" id=\"phnVal\" placeholder=\"Ex: 6974512311\">
                    <br>
                </div>
     

                <div class=\"form-content mt-4 mb-4\">
                    <span class=\"para1\">Gender:</span>
                    <input type=\"radio\" name=\"gender\" value=\"female\" id=\"gen\" class=\"gendr\">
                    <span class=\"para1\">Female</span>   
                    <input type=\"radio\" name=\"gender\" value=\"male\" id=\"gen\" class=\"gendr\">
                    <span class=\"para1\">Male</span>   
                    <input type=\"radio\" name=\"gender\" value=\"other\" id=\"gen\" class=\"gendr\">
                    <span class=\"para1\">Other</span>                   
                    <span id=\"\" class=\"error req-fd\">*</span>
                    <span id=\"okgender\" class=\"status ok-g hg\"><i class=\"fa-regular fa-circle-check\"></i></span>
                    <span id=\"unokgender\" class=\"status unok-r hg\"><i class=\"fa-regular fa-circle-xmark\"></i></span>
                    <span id=\"hintgender\" class=\"hint-css-p\"></span>
                </div>
                

                <div class=\"form-content\">
                <span class=\"para1\" >About Yourself:</span> 
                <span class=\"error req-fd\" id=\"titleHint\">*</span>
                <span id=\"okabout\" class=\"status ok-g habt\"><i class=\"fa-regular fa-circle-check\"></i></span>
                <span id=\"unokabout\" class=\"status unok-r habt\"><i class=\"fa-regular fa-circle-xmark\"></i></span>
                <span id=\"hintabout\" class=\"hint-css-p\"></span>
                <br><textarea name=\"about\" rows=\"3\" cols=\"40\" class=\"inp1\" id=\"habout\"></textarea>
                <br>
               </div>

               <div class=\"form-content\">
                <span class=\"para1\" >Address:</span> 
                <span class=\"error req-fd\" id=\"titleHint\">*</span>
                <span id=\"okadd\" class=\"status ok-g hadd\"><i class=\"fa-regular fa-circle-check\"></i></span>
                <span id=\"unokadd\" class=\"status unok-r hadd\"><i class=\"fa-regular fa-circle-xmark\"></i></span>
                <span id=\"hintadd\" class=\"hint-css-p\"></span>
                <br><textarea name=\"address\" rows=\"3\" cols=\"40\" class=\"inp1\" id=\"haddress\"></textarea>
                <br>
               </div>

               <div class=\"form-content\" >
                    <div class=\"select_option\" >
                    <select name=\"country\" class=\"form-select country inp1\" aria-label=\"Default select example\" onchange=\"return loadStates()\">
                        <option selected>Select Country</option>
                    </select>
                    <div class=\"select_option \">
                    <select name=\"state\" class=\"form-select state inp1 \" aria-label=\"Default select example\" onchange=\"loadCities()\">
                        <option selected>Select State</option>
                    </select>
                    <select name=\"city\" class=\"form-select city inp1\" aria-label=\"Default select example\">
                        <option selected>Select City</option>
                    </select>
                    </div>
                </div>



               <div class=\"form-content\">
                    <span class=\"para1\">Pin Code:</span>
                    <span class=\"error req-fd\" id=\"pinHint\">*</span>
                    <span id=\"okpin\" class=\"status ok-g hpin\"><i class=\"fa-regular fa-circle-check\"></i></span>
                    <span id=\"unokpin\" class=\"status unok-r hpin\"><i class=\"fa-regular fa-circle-xmark\"></i></span>
                    <span id=\"hintpin\" class=\"hint-css\"></span>
                    <br><input type=\"tel\" class=\"inp\" name=\"pincode\" id=\"pinVal\" placeholder=\"Ex: 276304\">
                    <br>
                </div>

                <div class=\"form-content\">
                    <span class=\"para1\">Password:</span>
                    <span class=\"error req-fd\">*
                    </span>
                    <span id=\"okpass\" class=\"status ok-g hcp\"><i class=\"fa-regular fa-circle-check\"></i></span>
                    <span id=\"unokpass\" class=\"status unok-r hcp\"><i class=\"fa-regular fa-circle-xmark\"></i></span>
                    <span id=\"hintpass\" class=\"hint-css-p\"></span>
                    <br><input type=\"password\" name=\"pass1\" value=\"\" class=\"inp\" id=\"passVal\">
                    <br>
                </div>

                <div class=\"form-content\">
                    <span class=\"para1\">Confirm Password:</span>
                    <span class=\"error req-fd\">*
                    </span>
                    <span id=\"okpasscnf\" class=\"status ok-g hcpc\"><i class=\"fa-regular fa-circle-check\"></i></span>
                    <span id=\"unokpasscnf\" class=\"status unok-r hcpc\"><i class=\"fa-regular fa-circle-xmark\"></i></span>
                    <span id=\"hintpasscnf\" class=\"hint-css-p\"></span>
                    <br><input type=\"password\" name=\"pass2\" value=\"\" class=\"inp\" id=\"passCnfVal\">
                    <br><br>
                </div>

                <div class=\"form-content mt-0\">
                <span class=\"error req-fd img-content\" id=\"imgHint\">*IMG Size less than 1MB and Ext: jpg, png, jpeg </span>
                    <label for=\"fileToUpload\" class=\"up-img\">Upload Image</label>
                         <input type=\"file\" name=\"fileToUpload\" id=\"fileToUpload\" value=\"\" class=\"upload-img bg-success\" >   
                         <span id=\"okimg\" class=\"status ok-g himg\"><i class=\"fa-regular fa-circle-check\"></i></span>
                         <span id=\"unokimg\" class=\"status unok-r himg\"><i class=\"fa-regular fa-circle-xmark\"></i></span>
                         <span id=\"hintimg\" class=\"hint-css-p\"></span>       
                </div>

                <div class=\"form-content captcha-div\">
                    <div class=\"e-captcha\" >
                        <label for=\"\" class=\"c-lable\">Enter Captcha:</label>
                        <span id=\"okcaptcha\" class=\"status ok-g hcc\"><i class=\"fa-regular fa-circle-check\"></i></span>
                        <span id=\"unokcaptcha\" class=\"status unok-r hcc\"><i class=\"fa-regular fa-circle-xmark\"></i></span>
                        <span id=\"hintcaptcha\" class=\"hint-captcha\"></span>
                        <input type=\"text\" id=\"captch\" class=\"c-code\">
                    </div>

                    <div class=\"inline reboot\" onclick=\"generate()\" id=\"hc\">
                        <br>
                        <i class=\"fa-solid fa-rotate-right logo\"></i>
                    </div>

                    <div id=\"cImg\" class=\"inline i-captcha\" selectable=\"False\">
                        <label for=\"\" class=\"c-lable\">Captcha Code:</label><br>
                        <p class=\"i-rnd\"><del><span id=\"random\"></span></del></p>
                    </div>
                </div>  
                
                <div class=\"form-content\">
                    <input type=\"checkbox\" name=\"\" value=\" \" class=\"check-box-term\" id = \"checkbox\">
                    <label for=\"\">I accept the Terms and Conditions.</label>
                    <span class=\"error req-fd\">*</span>
                        <span id=\"okcb\" class=\"status ok-g hcb\"><i class=\"fa-regular fa-circle-check\"></i></span>
                        <span id=\"unokcb\" class=\"status unok-r hcb\"><i class=\"fa-regular fa-circle-xmark\"></i></span>
                        <span id=\"hintcb\" class=\"hint-css-p\"></span>
                </div>

                <div class=\"form-content\">
                    <input type=\"submit\" name=\"submit\" value=\"REGISTER NOW\" class=\"preview\" id=\"sbt\" onmouseover=\"hoverbtn()\">
                </div>
            </form>
        </div>
    </div>


<div class=\"container-fluid p-0 footer-div\">

<footer class=\"bg-dark text-center text-white pt-5\">
  <div class=\"container p-4 pb-0\">
    <section class=\"mb-4\">
      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-facebook-f\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-twitter\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-google\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-instagram\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-linkedin-in\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-github\"></i></a>
    </section>
  </div>

  <div class=\"text-center p-3\" style=\"background-color: rgba(0, 0, 0, 0.2);\">
    © 2020 Copyright:
    <a class=\"text-white\" href=\"https://webkul.com/\">Webkul.com</a>
  </div>
</footer>
  
</div>


<script src=\"{{ asset('js/dropdown.js') }}\"></script>
{% endblock %}", "view/uRegistration.html.twig", "/home/users/shivam.baranwal/www/html/symfony_4/templates/view/uRegistration.html.twig");
    }
}
