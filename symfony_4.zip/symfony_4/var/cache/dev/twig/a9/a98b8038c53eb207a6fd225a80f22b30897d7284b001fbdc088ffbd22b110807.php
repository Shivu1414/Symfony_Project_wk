<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* view/userProfile.html.twig */
class __TwigTemplate_d437c520be935638f7248bf2e35c93a5e081bebdd08e19093b71955cbb8557a3 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'stylesheets' => [$this, 'block_stylesheets'],
            'javascripts' => [$this, 'block_javascripts'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "view/userProfile.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "view/userProfile.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "view/userProfile.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 2
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "Login Form";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 3
    public function block_stylesheets($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 4
        echo "        <link href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css\" rel=\"stylesheet\"integrity=\"sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN\" crossorigin=\"anonymous\">
        <link rel=\"stylesheet\" href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-alpha1/dist/css/bootstrap.min.css\">
        <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css\"integrity=\"sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==\"crossorigin=\"anonymous\" referrerpolicy=\"no-referrer\" />
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 9
    public function block_javascripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        // line 10
        echo "        <script src=\"https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js\"integrity=\"sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL\"crossorigin=\"anonymous\"></script>
        <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js\"></script>
        <script src=\"https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js\"></script>
        <script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js\"></script>
        <script src=\"https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-alpha1/dist/js/bootstrap.bundle.min.js\"></script>    
        <script src=\"https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js\"></script>
        <script src=\"";
        // line 16
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/profile.js"), "html", null, true);
        echo "\"></script>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 19
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 20
        echo "
<link href=\"";
        // line 21
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("css/userProfile.css"), "html", null, true);
        echo "\" rel=\"stylesheet\"/>

    <div class=\"container-fluid p-0\">
        <nav class=\"navbar navbar p-0\">
            <a class=\"navbar-brand \" href=\"#\">
                <img src=\"";
        // line 26
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/webkul_logo.png"), "html", null, true);
        echo "\" class=\"logo\" alt=\"\"><span class=\"logo-content\"> Webkul</span>
            </a>
        </nav>
    </div>


    <div class=\"container rounded bg-white mt-2 mb-5\">
        <div class=\"row\">

            <div class=\"col-md-3 border-right\">
                <div class=\"d-flex flex-column align-items-center text-center p-3 py-5\">
                    <span class=\"head1\">Hello ";
        // line 37
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["profile"]) || array_key_exists("profile", $context) ? $context["profile"] : (function () { throw new RuntimeError('Variable "profile" does not exist.', 37, $this->source); })()), "firstname", [], "any", false, false, false, 37), "html", null, true);
        echo "
                    </span>
                    <img src=";
        // line 39
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl(twig_get_attribute($this->env, $this->source, (isset($context["profile"]) || array_key_exists("profile", $context) ? $context["profile"] : (function () { throw new RuntimeError('Variable "profile" does not exist.', 39, $this->source); })()), "url", [], "any", false, false, false, 39)), "html", null, true);
        echo " class=\"rounded-circle mt-5\" width=\"200px\">
                    <span class=\"font-weight-bold mt-3\">
                        ";
        // line 41
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["profile"]) || array_key_exists("profile", $context) ? $context["profile"] : (function () { throw new RuntimeError('Variable "profile" does not exist.', 41, $this->source); })()), "firstname", [], "any", false, false, false, 41), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["profile"]) || array_key_exists("profile", $context) ? $context["profile"] : (function () { throw new RuntimeError('Variable "profile" does not exist.', 41, $this->source); })()), "lastname", [], "any", false, false, false, 41), "html", null, true);
        echo "
                    </span>
                    <span class=\"text-black-50\">
                        ";
        // line 44
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["profile"]) || array_key_exists("profile", $context) ? $context["profile"] : (function () { throw new RuntimeError('Variable "profile" does not exist.', 44, $this->source); })()), "email", [], "any", false, false, false, 44), "html", null, true);
        echo "
                    </span>
                    <span> </span>
                </div>
            </div>
            <div class=\"col-md-5 border-right\">
                <div class=\"p-3 py-5\">
                    <div class=\"d-flex justify-content-between align-items-center mb-3\">
                        <h4 class=\"text-right\">Your Profile</h4>
                    </div>
                    <div class=\"row mt-2\">
                        <div class=\"col-md-6\"><label class=\"labels\">First Name:</label><input type=\"text\" class=\"form-control\" placeholder=\"first name\" value=\"";
        // line 55
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["profile"]) || array_key_exists("profile", $context) ? $context["profile"] : (function () { throw new RuntimeError('Variable "profile" does not exist.', 55, $this->source); })()), "firstname", [], "any", false, false, false, 55), "html", null, true);
        echo "\">
                        </div>
                        <div class=\"col-md-6\"><label class=\"labels\">Last Name:</label><input type=\"text\" class=\"form-control\" value=\"";
        // line 57
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["profile"]) || array_key_exists("profile", $context) ? $context["profile"] : (function () { throw new RuntimeError('Variable "profile" does not exist.', 57, $this->source); })()), "lastname", [], "any", false, false, false, 57), "html", null, true);
        echo "\" placeholder=\"surname\">
                        </div>
                    </div>
                    <div class=\"row mt-3\">
                        <div class=\"col-md-12\"><label class=\"labels\">Email ID:</label><input type=\"text\" class=\"form-control\" placeholder=\"enter email id\" value=\"";
        // line 61
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["profile"]) || array_key_exists("profile", $context) ? $context["profile"] : (function () { throw new RuntimeError('Variable "profile" does not exist.', 61, $this->source); })()), "email", [], "any", false, false, false, 61), "html", null, true);
        echo "\">
                        </div>
                        <div class=\"col-md-12\"><label class=\"labels\">Mobile Number:</label><input type=\"text\" class=\"form-control\" placeholder=\"enter phone number\" value=\"";
        // line 63
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["profile"]) || array_key_exists("profile", $context) ? $context["profile"] : (function () { throw new RuntimeError('Variable "profile" does not exist.', 63, $this->source); })()), "phone", [], "any", false, false, false, 63), "html", null, true);
        echo "\"></div>
                        <div class=\"col-md-12\"><label class=\"labels\">User Address:</label><input type=\"text\" class=\"form-control\" placeholder=\"enter address \" value=\"";
        // line 64
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["profile"]) || array_key_exists("profile", $context) ? $context["profile"] : (function () { throw new RuntimeError('Variable "profile" does not exist.', 64, $this->source); })()), "address", [], "any", false, false, false, 64), "html", null, true);
        echo "\"></div>
                        <div class=\"col-md-12\"><label class=\"labels\">Postcode:</label><input type=\"text\" class=\"form-control\" placeholder=\"enter pincode\" value=\"";
        // line 65
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["profile"]) || array_key_exists("profile", $context) ? $context["profile"] : (function () { throw new RuntimeError('Variable "profile" does not exist.', 65, $this->source); })()), "pincode", [], "any", false, false, false, 65), "html", null, true);
        echo "\">
                        </div>
                        <div class=\"col-md-12\"><label class=\"labels\">State:</label><input type=\"text\" class=\"form-control\" placeholder=\"state\" value=\"";
        // line 67
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["profile"]) || array_key_exists("profile", $context) ? $context["profile"] : (function () { throw new RuntimeError('Variable "profile" does not exist.', 67, $this->source); })()), "state", [], "any", false, false, false, 67), "html", null, true);
        echo "\"></div>
                    </div>
                    <div class=\"row mt-3\">
                        <div class=\"col-md-6\"><label class=\"labels\">Country</label><input type=\"text\" class=\"form-control\" placeholder=\"country\" value=\"";
        // line 70
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["profile"]) || array_key_exists("profile", $context) ? $context["profile"] : (function () { throw new RuntimeError('Variable "profile" does not exist.', 70, $this->source); })()), "country", [], "any", false, false, false, 70), "html", null, true);
        echo "\">
                        </div>
                        <div class=\"col-md-6\"><label class=\"labels\">State/Region</label><input type=\"text\" class=\"form-control\" value=\"";
        // line 72
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["profile"]) || array_key_exists("profile", $context) ? $context["profile"] : (function () { throw new RuntimeError('Variable "profile" does not exist.', 72, $this->source); })()), "city", [], "any", false, false, false, 72), "html", null, true);
        echo "\" placeholder=\"city\"></div>
                    </div>
                    <div class=\"row mt-3\">
                        <div class=\"col-md-6\"><label class=\"labels\">Gender:</label><input type=\"text\" class=\"form-control\" placeholder=\"gender\" value=\"";
        // line 75
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["profile"]) || array_key_exists("profile", $context) ? $context["profile"] : (function () { throw new RuntimeError('Variable "profile" does not exist.', 75, $this->source); })()), "gender", [], "any", false, false, false, 75), "html", null, true);
        echo "\" disabled></div>
                    </div>

                </div>
            </div>



            <div class=\"col-md-4 mt-3\">
                <span id=\"hintpost\" class=\"hint-css postjob\">Create New Job</span><br>
                <span class=\"plus-icon hpost\"><a href=\"";
        // line 85
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("blog", ["mail" => twig_get_attribute($this->env, $this->source, (isset($context["profile"]) || array_key_exists("profile", $context) ? $context["profile"] : (function () { throw new RuntimeError('Variable "profile" does not exist.', 85, $this->source); })()), "email", [], "any", false, false, false, 85)]), "html", null, true);
        echo "\" class=\"text-white\"><i class=\"fa-solid fa-plus\"></i></a></span>
                <a href=\"";
        // line 86
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("logout");
        echo "\"><input type=\"submit\" name=\"submit\" value=\"LOGOUT\" class=\"preview \" onclick=\"return logout()\"></a>

                <div class=\"p-3 py-5 \">
                    <div class=\"col-md-12\">
                    <label class=\"labels\">About Mr. ";
        // line 90
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["profile"]) || array_key_exists("profile", $context) ? $context["profile"] : (function () { throw new RuntimeError('Variable "profile" does not exist.', 90, $this->source); })()), "firstname", [], "any", false, false, false, 90), "html", null, true);
        echo " :</label>
                    <input type=\"text\" class=\"form-control\" placeholder=\"about your self\" value=\"";
        // line 91
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["profile"]) || array_key_exists("profile", $context) ? $context["profile"] : (function () { throw new RuntimeError('Variable "profile" does not exist.', 91, $this->source); })()), "about", [], "any", false, false, false, 91), "html", null, true);
        echo "\"></div> <br>
                    <a href=\"";
        // line 92
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("userallpost", ["mail" => twig_get_attribute($this->env, $this->source, (isset($context["profile"]) || array_key_exists("profile", $context) ? $context["profile"] : (function () { throw new RuntimeError('Variable "profile" does not exist.', 92, $this->source); })()), "email", [], "any", false, false, false, 92)]), "html", null, true);
        echo "\"><input type=\"submit\" name=\"submit\" value=\"View All Your Posted Jobs\" class=\"pre-post\"></a>
                    <a href=\"";
        // line 93
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("jobdata", ["mail" => twig_get_attribute($this->env, $this->source, (isset($context["profile"]) || array_key_exists("profile", $context) ? $context["profile"] : (function () { throw new RuntimeError('Variable "profile" does not exist.', 93, $this->source); })()), "email", [], "any", false, false, false, 93)]), "html", null, true);
        echo "\"><input type=\"submit\" name=\"submit\" value=\"View Your Unpublish Jobs\" class=\"pre-post new-post\"></a>
                </div>
                <div class=\" \">
                    <a href=\"";
        // line 96
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("profile_edit", ["mail" => twig_get_attribute($this->env, $this->source, (isset($context["profile"]) || array_key_exists("profile", $context) ? $context["profile"] : (function () { throw new RuntimeError('Variable "profile" does not exist.', 96, $this->source); })()), "email", [], "any", false, false, false, 96)]), "html", null, true);
        echo "\" class=\"edit-view text-decoration-none\" onclick=\"return cnfEdit()\">Edit Profile</a>
                </div>
            </div>


        </div>
    </div>
    </div>
    </div>

<div class=\"container-fluid p-0 mt-5\">

  <footer class=\"bg-dark text-center text-white pt-5\">
  <div class=\"container p-4 pb-0\">
    <section class=\"mb-4\">
      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-facebook-f\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-twitter\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-google\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-instagram\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-linkedin-in\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-github\"></i></a>
    </section>
  </div>

  <div class=\"text-center p-3\" style=\"background-color: rgba(0, 0, 0, 0.2);\">
    © 2020 Copyright:
    <a class=\"text-white\" href=\"https://webkul.com/\">webkul.com</a>
  </div>
</footer>
  
</div>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "view/userProfile.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable()
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  290 => 96,  284 => 93,  280 => 92,  276 => 91,  272 => 90,  265 => 86,  261 => 85,  248 => 75,  242 => 72,  237 => 70,  231 => 67,  226 => 65,  222 => 64,  218 => 63,  213 => 61,  206 => 57,  201 => 55,  187 => 44,  179 => 41,  174 => 39,  169 => 37,  155 => 26,  147 => 21,  144 => 20,  134 => 19,  121 => 16,  113 => 10,  103 => 9,  90 => 4,  80 => 3,  61 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}
{% block title %}Login Form{% endblock %}
{% block stylesheets %}
        <link href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css\" rel=\"stylesheet\"integrity=\"sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN\" crossorigin=\"anonymous\">
        <link rel=\"stylesheet\" href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-alpha1/dist/css/bootstrap.min.css\">
        <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css\"integrity=\"sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==\"crossorigin=\"anonymous\" referrerpolicy=\"no-referrer\" />
{% endblock %}

{% block javascripts %}
        <script src=\"https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js\"integrity=\"sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL\"crossorigin=\"anonymous\"></script>
        <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js\"></script>
        <script src=\"https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js\"></script>
        <script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js\"></script>
        <script src=\"https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-alpha1/dist/js/bootstrap.bundle.min.js\"></script>    
        <script src=\"https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js\"></script>
        <script src=\"{{ asset('js/profile.js') }}\"></script>

{% endblock %}
{% block body %}

<link href=\"{{ asset('css/userProfile.css') }}\" rel=\"stylesheet\"/>

    <div class=\"container-fluid p-0\">
        <nav class=\"navbar navbar p-0\">
            <a class=\"navbar-brand \" href=\"#\">
                <img src=\"{{ asset('img/webkul_logo.png') }}\" class=\"logo\" alt=\"\"><span class=\"logo-content\"> Webkul</span>
            </a>
        </nav>
    </div>


    <div class=\"container rounded bg-white mt-2 mb-5\">
        <div class=\"row\">

            <div class=\"col-md-3 border-right\">
                <div class=\"d-flex flex-column align-items-center text-center p-3 py-5\">
                    <span class=\"head1\">Hello {{profile.firstname}}
                    </span>
                    <img src={{asset(profile.url)}} class=\"rounded-circle mt-5\" width=\"200px\">
                    <span class=\"font-weight-bold mt-3\">
                        {{profile.firstname}} {{profile.lastname}}
                    </span>
                    <span class=\"text-black-50\">
                        {{profile.email}}
                    </span>
                    <span> </span>
                </div>
            </div>
            <div class=\"col-md-5 border-right\">
                <div class=\"p-3 py-5\">
                    <div class=\"d-flex justify-content-between align-items-center mb-3\">
                        <h4 class=\"text-right\">Your Profile</h4>
                    </div>
                    <div class=\"row mt-2\">
                        <div class=\"col-md-6\"><label class=\"labels\">First Name:</label><input type=\"text\" class=\"form-control\" placeholder=\"first name\" value=\"{{profile.firstname}}\">
                        </div>
                        <div class=\"col-md-6\"><label class=\"labels\">Last Name:</label><input type=\"text\" class=\"form-control\" value=\"{{profile.lastname}}\" placeholder=\"surname\">
                        </div>
                    </div>
                    <div class=\"row mt-3\">
                        <div class=\"col-md-12\"><label class=\"labels\">Email ID:</label><input type=\"text\" class=\"form-control\" placeholder=\"enter email id\" value=\"{{profile.email}}\">
                        </div>
                        <div class=\"col-md-12\"><label class=\"labels\">Mobile Number:</label><input type=\"text\" class=\"form-control\" placeholder=\"enter phone number\" value=\"{{profile.phone}}\"></div>
                        <div class=\"col-md-12\"><label class=\"labels\">User Address:</label><input type=\"text\" class=\"form-control\" placeholder=\"enter address \" value=\"{{profile.address}}\"></div>
                        <div class=\"col-md-12\"><label class=\"labels\">Postcode:</label><input type=\"text\" class=\"form-control\" placeholder=\"enter pincode\" value=\"{{profile.pincode}}\">
                        </div>
                        <div class=\"col-md-12\"><label class=\"labels\">State:</label><input type=\"text\" class=\"form-control\" placeholder=\"state\" value=\"{{profile.state}}\"></div>
                    </div>
                    <div class=\"row mt-3\">
                        <div class=\"col-md-6\"><label class=\"labels\">Country</label><input type=\"text\" class=\"form-control\" placeholder=\"country\" value=\"{{profile.country}}\">
                        </div>
                        <div class=\"col-md-6\"><label class=\"labels\">State/Region</label><input type=\"text\" class=\"form-control\" value=\"{{profile.city}}\" placeholder=\"city\"></div>
                    </div>
                    <div class=\"row mt-3\">
                        <div class=\"col-md-6\"><label class=\"labels\">Gender:</label><input type=\"text\" class=\"form-control\" placeholder=\"gender\" value=\"{{profile.gender}}\" disabled></div>
                    </div>

                </div>
            </div>



            <div class=\"col-md-4 mt-3\">
                <span id=\"hintpost\" class=\"hint-css postjob\">Create New Job</span><br>
                <span class=\"plus-icon hpost\"><a href=\"{{path('blog',{'mail': profile.email})}}\" class=\"text-white\"><i class=\"fa-solid fa-plus\"></i></a></span>
                <a href=\"{{path('logout')}}\"><input type=\"submit\" name=\"submit\" value=\"LOGOUT\" class=\"preview \" onclick=\"return logout()\"></a>

                <div class=\"p-3 py-5 \">
                    <div class=\"col-md-12\">
                    <label class=\"labels\">About Mr. {{profile.firstname}} :</label>
                    <input type=\"text\" class=\"form-control\" placeholder=\"about your self\" value=\"{{profile.about}}\"></div> <br>
                    <a href=\"{{path('userallpost',{'mail': profile.email })}}\"><input type=\"submit\" name=\"submit\" value=\"View All Your Posted Jobs\" class=\"pre-post\"></a>
                    <a href=\"{{path('jobdata',{'mail': profile.email })}}\"><input type=\"submit\" name=\"submit\" value=\"View Your Unpublish Jobs\" class=\"pre-post new-post\"></a>
                </div>
                <div class=\" \">
                    <a href=\"{{path('profile_edit',{'mail': profile.email })}}\" class=\"edit-view text-decoration-none\" onclick=\"return cnfEdit()\">Edit Profile</a>
                </div>
            </div>


        </div>
    </div>
    </div>
    </div>

<div class=\"container-fluid p-0 mt-5\">

  <footer class=\"bg-dark text-center text-white pt-5\">
  <div class=\"container p-4 pb-0\">
    <section class=\"mb-4\">
      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-facebook-f\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-twitter\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-google\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-instagram\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-linkedin-in\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-github\"></i></a>
    </section>
  </div>

  <div class=\"text-center p-3\" style=\"background-color: rgba(0, 0, 0, 0.2);\">
    © 2020 Copyright:
    <a class=\"text-white\" href=\"https://webkul.com/\">webkul.com</a>
  </div>
</footer>
  
</div>

{% endblock %}", "view/userProfile.html.twig", "/home/users/shivam.baranwal/www/html/symfony_4/templates/view/userProfile.html.twig");
    }
}
