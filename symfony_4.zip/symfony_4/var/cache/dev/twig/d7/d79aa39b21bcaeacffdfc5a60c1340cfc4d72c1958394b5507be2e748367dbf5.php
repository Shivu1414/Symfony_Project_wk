<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* view/userAllPosts.html.twig */
class __TwigTemplate_99127c6a2385f2ee786e61eed1d2ba928c7561c937c05d125bb5e4fc4a1eb7cc extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'stylesheets' => [$this, 'block_stylesheets'],
            'javascripts' => [$this, 'block_javascripts'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "view/userAllPosts.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "view/userAllPosts.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "view/userAllPosts.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 2
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "Login Form";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 3
    public function block_stylesheets($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 4
        echo "        <link href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css\" rel=\"stylesheet\"integrity=\"sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN\" crossorigin=\"anonymous\">
        <link rel=\"stylesheet\" href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-alpha1/dist/css/bootstrap.min.css\">
        <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css\"integrity=\"sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==\"crossorigin=\"anonymous\" referrerpolicy=\"no-referrer\" />
        <link rel=\"stylesheet\" href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-alpha1/dist/css/bootstrap.min.css\">
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 10
    public function block_javascripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        // line 11
        echo "        <script src=\"https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js\"integrity=\"sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL\"crossorigin=\"anonymous\"></script>
        <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js\"></script>
        <script src=\"https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js\"></script>
        <script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js\"></script>
        <script src=\"https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-alpha1/dist/js/bootstrap.bundle.min.js\"></script>    
        <script src=\"https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js\"></script>
        <script src=\"https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-alpha1/dist/js/bootstrap.bundle.min.js\"></script>
        <script src=\"https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js\"></script>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 20
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 21
        echo "
<link href=\"";
        // line 22
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("css/createdJobData.css"), "html", null, true);
        echo "\" rel=\"stylesheet\"/>
<link href=\"";
        // line 23
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("css/userAllPosts.css"), "html", null, true);
        echo "\" rel=\"stylesheet\"/>

        <div id=\"overlay\"></div>
        <div id=\"popup\">
            ";
        // line 27
        if ((0 === twig_compare((isset($context["posts"]) || array_key_exists("posts", $context) ? $context["posts"] : (function () { throw new RuntimeError('Variable "posts" does not exist.', 27, $this->source); })()), ""))) {
            // line 28
            echo "                <div class=\"textview lgview\">Welcome! Webkul</div>
            ";
        } else {
            // line 30
            echo "            <div class=\"\">
                  <img src=";
            // line 31
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl(twig_get_attribute($this->env, $this->source, (isset($context["posts"]) || array_key_exists("posts", $context) ? $context["posts"] : (function () { throw new RuntimeError('Variable "posts" does not exist.', 31, $this->source); })()), "url", [], "any", false, false, false, 31)), "html", null, true);
            echo " class=\"rounded-circle viewpic\" width=\"20px\" height=\"20px\">
                </div>             
              <div class=\"\">
                <div class=\"textview\">Name: ";
            // line 34
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["posts"]) || array_key_exists("posts", $context) ? $context["posts"] : (function () { throw new RuntimeError('Variable "posts" does not exist.', 34, $this->source); })()), "name", [], "any", false, false, false, 34), "html", null, true);
            echo "</div>
                <div class=\"textview\">Email: ";
            // line 35
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["posts"]) || array_key_exists("posts", $context) ? $context["posts"] : (function () { throw new RuntimeError('Variable "posts" does not exist.', 35, $this->source); })()), "email", [], "any", false, false, false, 35), "html", null, true);
            echo "</div>
                <div class=\"textview\">Location: ";
            // line 36
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["posts"]) || array_key_exists("posts", $context) ? $context["posts"] : (function () { throw new RuntimeError('Variable "posts" does not exist.', 36, $this->source); })()), "location", [], "any", false, false, false, 36), "html", null, true);
            echo "</div>
                <div class=\"textview\">Title: ";
            // line 37
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["posts"]) || array_key_exists("posts", $context) ? $context["posts"] : (function () { throw new RuntimeError('Variable "posts" does not exist.', 37, $this->source); })()), "title", [], "any", false, false, false, 37), "html", null, true);
            echo "</div>
              </div>
            ";
        }
        // line 40
        echo "        </div>


<div class=\"body\">
    <div class=\"container-fluid p-0\">
    

        <nav class=\"navbar navbar p-0\">
        <div class=\"left\">
            <div class=\"logo\">
                <a class=\"navbar-brand \" href=\"#\">
                <img src=\"";
        // line 51
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/webkul_logo.png"), "html", null, true);
        echo "\" class=\"logo\" alt=\"\">
                </a>
            </div>
            <div class=\"webkul\">
            <span class=\"logo-content\"> Webkul</span>
            </div>
        </div>
        <div class=\"nav-right\">
          <a href=\"";
        // line 59
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("userprofile", ["mail" => (isset($context["mail"]) || array_key_exists("mail", $context) ? $context["mail"] : (function () { throw new RuntimeError('Variable "mail" does not exist.', 59, $this->source); })())]), "html", null, true);
        echo "\" class=\"link1\">User Profile</a>
          <a href=\"";
        // line 60
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("logout");
        echo "\" class=\"link1\" onclick=\"return logout()\">Logout</a>
        </div>
        </nav>
    </div>
    
    <div class=\"container justify-content-center\">
    
    <div class=\"row\">
      <div class=\"colomb-srch\">     
      <form method=\"post\" action=\"";
        // line 69
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("allPostsrch", ["mail" => (isset($context["mail"]) || array_key_exists("mail", $context) ? $context["mail"] : (function () { throw new RuntimeError('Variable "mail" does not exist.', 69, $this->source); })()), "val" => (isset($context["temp"]) || array_key_exists("temp", $context) ? $context["temp"] : (function () { throw new RuntimeError('Variable "temp" does not exist.', 69, $this->source); })())]), "html", null, true);
        echo "\" class=\"search-form\">     
      <div class=\"input-group mb-3\">
         <input type=\"text\" name=\"search\" class=\"form-control input-text\" placeholder=\"Search products....\" aria-label=\"Recipient's username\" aria-describedby=\"basic-addon2\">
         <div class=\"input-group-append\">
        <button class=\"btn btn-srch btn-lg\" type=\"search\"><i class=\"fa fa-search\"></i></button>
      </div>
    </div>           
    </div>  

    </div>
    
    
</div>

";
        // line 101
        echo "
    <div class=\"row m-0 p-0\">
      <div class=\"col-lg-3 m-0 p-0\">
        ";
        // line 107
        echo "       </div>
      <div class=\"col-lg-6 m-0 p-0\">
           <div class=\"m-link\">
           <div class=\"btm-para\">Users all Publish and Unpublish posts.";
        // line 110
        echo twig_escape_filter($this->env, (isset($context["pg"]) || array_key_exists("pg", $context) ? $context["pg"] : (function () { throw new RuntimeError('Variable "pg" does not exist.', 110, $this->source); })()), "html", null, true);
        echo "</div>
           </div>   
      </div>

      <div class=\"col-lg-3 m-0 p-0\">
          <div class=\"f-link s-link\">
            <div class=\"dropdown show\">
              <a class=\"dropdwn dropdown-toggle\" href=\"#\" role=\"button\" id=\"dropdownMenuLink\" data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">";
        // line 117
        echo twig_escape_filter($this->env, (isset($context["type"]) || array_key_exists("type", $context) ? $context["type"] : (function () { throw new RuntimeError('Variable "type" does not exist.', 117, $this->source); })()), "html", null, true);
        echo "</a>
                <div class=\"dropdown-menu\" aria-labelledby=\"dropdownMenuLink\">
                   <a class=\"dropdown-item\" href=\"";
        // line 119
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("userallpost", ["mail" => (isset($context["mail"]) || array_key_exists("mail", $context) ? $context["mail"] : (function () { throw new RuntimeError('Variable "mail" does not exist.', 119, $this->source); })()), "val" => 1]), "html", null, true);
        echo "\">Publish Posts</a>
                   <a class=\"dropdown-item\" href=\"";
        // line 120
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("userallpost", ["mail" => (isset($context["mail"]) || array_key_exists("mail", $context) ? $context["mail"] : (function () { throw new RuntimeError('Variable "mail" does not exist.', 120, $this->source); })()), "val" => 2]), "html", null, true);
        echo "\">Unpublish Posts</a>
                   ";
        // line 122
        echo "                </div>
            </div>
           </div>              
      </div>
    </div>


    



    <div class=\"div2 tag\">
    <form method=\"POST\" action=\"";
        // line 134
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("multidelAPosts", ["mail" => (isset($context["mail"]) || array_key_exists("mail", $context) ? $context["mail"] : (function () { throw new RuntimeError('Variable "mail" does not exist.', 134, $this->source); })()), "temp" => (isset($context["temp"]) || array_key_exists("temp", $context) ? $context["temp"] : (function () { throw new RuntimeError('Variable "temp" does not exist.', 134, $this->source); })())]), "html", null, true);
        echo "\">
    <input type=\"submit\" name=\"mul_delete\" class=\"mul-del\" value=\"Delete\" onclick=\"return mulDel()\">
      <table class=\"table1\" border=\"1\" cellSpacing=\"0\"> 
        <thead class=\"thead-dark\">
          <tr >
            <th class=\"col\" width=\"9%\"><input type=\"checkbox\" id=\"select_all\" name=\"\" value=\"\"></th>
            <th class=\"col\" width=\"9%\">Company </th>
            <th class=\"col\" width=\"16%\">Name</th>
            <th class=\"col\" width=\"20%\">Email</th>
            <th class=\"col\" width=\"12%\">Location</th>
            <th class=\"col\" width=\"15%\">Title</th>
            <th class=\"col\" width=\"19%\">Actions</th>

          </tr>
        </thead>
      </table>

      ";
        // line 151
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["publishJobs"]) || array_key_exists("publishJobs", $context) ? $context["publishJobs"] : (function () { throw new RuntimeError('Variable "publishJobs" does not exist.', 151, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["job"]) {
            echo "  
      <table class=\"table1 table2\" border=\"1\" cellSpacing=\"0\" >

        <tbody>
          <tr height=\"\">
            <td width=\"9%\"><input type=\"checkbox\" name=\"multiple_delete[]\" value=";
            // line 156
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["job"], "id", [], "any", false, false, false, 156), "html", null, true);
            echo " class=\"checkbox\"> </td>
            <td width=\"9%\"><img src=";
            // line 157
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl(twig_get_attribute($this->env, $this->source, $context["job"], "url", [], "any", false, false, false, 157)), "html", null, true);
            echo " alt=\"\" class=\"img-data\"></td>
            <td width=\"16%\">";
            // line 158
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["job"], "name", [], "any", false, false, false, 158), "html", null, true);
            echo "</td>
            <td width=\"20%\">";
            // line 159
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["job"], "email", [], "any", false, false, false, 159), "html", null, true);
            echo "</td>
            <td width=\"12%\">";
            // line 160
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["job"], "location", [], "any", false, false, false, 160), "html", null, true);
            echo "</td>
            <td width=\"15%\">";
            // line 161
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["job"], "title", [], "any", false, false, false, 161), "html", null, true);
            echo "</td>
            <td width=\"19%\">
                <a href=\"";
            // line 163
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("delpubpost", ["id" => twig_get_attribute($this->env, $this->source, $context["job"], "id", [], "any", false, false, false, 163), "mail" => twig_get_attribute($this->env, $this->source, $context["job"], "email", [], "any", false, false, false, 163)]), "html", null, true);
            echo "\" class=\"delete\" onclick=\"return cnfDelete();\"><i class=\"fa-solid fa-trash\"></i></a>
                <a href=\"";
            // line 164
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("editpostjob", ["id" => twig_get_attribute($this->env, $this->source, $context["job"], "id", [], "any", false, false, false, 164), "mail" => twig_get_attribute($this->env, $this->source, $context["job"], "email", [], "any", false, false, false, 164)]), "html", null, true);
            echo "\" class=\"update\" onclick=\"return cnfEdit();\"><i class=\"fa-solid fa-pen\" ></i></a>
                <a href=\"";
            // line 165
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("userpostview", ["mail" => twig_get_attribute($this->env, $this->source, $context["job"], "email", [], "any", false, false, false, 165), "val" => 1, "id" => twig_get_attribute($this->env, $this->source, $context["job"], "id", [], "any", false, false, false, 165), "tag" => 1, "pg" => (isset($context["pg"]) || array_key_exists("pg", $context) ? $context["pg"] : (function () { throw new RuntimeError('Variable "pg" does not exist.', 165, $this->source); })()), "page" => (isset($context["pg"]) || array_key_exists("pg", $context) ? $context["pg"] : (function () { throw new RuntimeError('Variable "pg" does not exist.', 165, $this->source); })())]), "html", null, true);
            echo "\" class=\"publish viewbtn\" onclick=\"return cnfView();\"><i class=\"fa-solid fa-eye\"></i></a>
                <a href=\"";
            // line 166
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("unpubdata", ["id" => twig_get_attribute($this->env, $this->source, $context["job"], "id", [], "any", false, false, false, 166), "mail" => twig_get_attribute($this->env, $this->source, $context["job"], "email", [], "any", false, false, false, 166)]), "html", null, true);
            echo "\" class=\"publish\" onclick=\"return cnfUnpublish();\"><i class=\"fa-solid fa-download\"></i></a>
            </td>
          </tr>
        </tbody>
        </table>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['job'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 172
        echo "


        ";
        // line 175
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["unpublishJobs"]) || array_key_exists("unpublishJobs", $context) ? $context["unpublishJobs"] : (function () { throw new RuntimeError('Variable "unpublishJobs" does not exist.', 175, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["job"]) {
            echo "  
         <table class=\"table1 table2\" border=\"1\" cellSpacing=\"0\" >


         <tbody>
          <tr height=\"\">
            <td width=\"9%\"><input type=\"checkbox\" name=\"multiple_delete[]\" value=";
            // line 181
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["job"], "id", [], "any", false, false, false, 181), "html", null, true);
            echo " class=\"checkbox\"> </td>
            <td width=\"9%\"><img src=";
            // line 182
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl(twig_get_attribute($this->env, $this->source, $context["job"], "url", [], "any", false, false, false, 182)), "html", null, true);
            echo " alt=\"\" class=\"img-data\"></td>
            <td width=\"16%\">";
            // line 183
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["job"], "name", [], "any", false, false, false, 183), "html", null, true);
            echo "</td>
            <td width=\"20%\">";
            // line 184
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["job"], "email", [], "any", false, false, false, 184), "html", null, true);
            echo "</td>
            <td width=\"12%\">";
            // line 185
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["job"], "location", [], "any", false, false, false, 185), "html", null, true);
            echo "</td>
            <td width=\"15%\">";
            // line 186
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["job"], "title", [], "any", false, false, false, 186), "html", null, true);
            echo "</td>
            <td width=\"19%\">
                <a href=\"";
            // line 188
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("delunpubpost", ["id" => twig_get_attribute($this->env, $this->source, $context["job"], "id", [], "any", false, false, false, 188), "mail" => twig_get_attribute($this->env, $this->source, $context["job"], "email", [], "any", false, false, false, 188)]), "html", null, true);
            echo "\" class=\"delete\" onclick=\"return cnfDelete();\"><i class=\"fa-solid fa-trash\"></i></a>
                <a href=\"";
            // line 189
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("editunpostjob", ["id" => twig_get_attribute($this->env, $this->source, $context["job"], "id", [], "any", false, false, false, 189), "mail" => twig_get_attribute($this->env, $this->source, $context["job"], "email", [], "any", false, false, false, 189)]), "html", null, true);
            echo "\" class=\"update\" onclick=\"return cnfEdit();\"><i class=\"fa-solid fa-pen\" ></i></a>
                <a href=\"";
            // line 190
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("userpostview", ["mail" => twig_get_attribute($this->env, $this->source, $context["job"], "email", [], "any", false, false, false, 190), "val" => 2, "id" => twig_get_attribute($this->env, $this->source, $context["job"], "id", [], "any", false, false, false, 190), "tag" => 1, "pg" => (isset($context["pg"]) || array_key_exists("pg", $context) ? $context["pg"] : (function () { throw new RuntimeError('Variable "pg" does not exist.', 190, $this->source); })()), "page" => (isset($context["pg"]) || array_key_exists("pg", $context) ? $context["pg"] : (function () { throw new RuntimeError('Variable "pg" does not exist.', 190, $this->source); })())]), "html", null, true);
            echo "\" class=\"publish viewbtn\" onclick=\"cnfView();\"><i class=\"fa-solid fa-eye\"></i></a>
                <a href=\"";
            // line 191
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("pubdata", ["id" => twig_get_attribute($this->env, $this->source, $context["job"], "id", [], "any", false, false, false, 191), "mail" => twig_get_attribute($this->env, $this->source, $context["job"], "email", [], "any", false, false, false, 191)]), "html", null, true);
            echo "\" class=\"publish\" onchange=\"return cnfPublish();\"><i class=\"fa-solid fa-upload\"></i></a>
            </td>
          </tr>
        </tbody>
        </table>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['job'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 197
        echo "


        </form>
        <br>
        <div class=\"paginate\">
        ";
        // line 203
        if ((0 === twig_compare((isset($context["unpublishJobs"]) || array_key_exists("unpublishJobs", $context) ? $context["unpublishJobs"] : (function () { throw new RuntimeError('Variable "unpublishJobs" does not exist.', 203, $this->source); })()), ""))) {
            // line 204
            echo "        ";
            echo $this->extensions['Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension']->render($this->env, (isset($context["publishJobs"]) || array_key_exists("publishJobs", $context) ? $context["publishJobs"] : (function () { throw new RuntimeError('Variable "publishJobs" does not exist.', 204, $this->source); })()));
            echo "
        ";
        } else {
            // line 206
            echo "        ";
            echo $this->extensions['Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension']->render($this->env, (isset($context["unpublishJobs"]) || array_key_exists("unpublishJobs", $context) ? $context["unpublishJobs"] : (function () { throw new RuntimeError('Variable "unpublishJobs" does not exist.', 206, $this->source); })()));
            echo "
        ";
        }
        // line 208
        echo "        </div>
      </div>
   </div>
</div> 

</div>

<div class=\"container-fluid p-0 mt-5\">

  <footer class=\"bg-dark text-center text-white pt-5\">
  <div class=\"container p-4 pb-0\">
    <section class=\"mb-4\">
      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-facebook-f\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-twitter\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-google\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-instagram\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-linkedin-in\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-github\"></i></a>
    </section>
  </div>

  <div class=\"text-center p-3\" style=\"background-color: rgba(0, 0, 0, 0.2);\">
    © 2020 Copyright:
    <input type=\"text\" id=\"tg\" value=";
        // line 236
        echo twig_escape_filter($this->env, (isset($context["tag"]) || array_key_exists("tag", $context) ? $context["tag"] : (function () { throw new RuntimeError('Variable "tag" does not exist.', 236, $this->source); })()), "html", null, true);
        echo " disabled>
    <a class=\"text-white\" href=\"https://webkul.com/\">webkul.com</a>
  </div>
</footer>
  
</div>

  <script src=\"";
        // line 243
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/createdJobData.js"), "html", null, true);
        echo "\"></script>
  <script src=\"";
        // line 244
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/userAllPost.js"), "html", null, true);
        echo "\"></script>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "view/userAllPosts.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable()
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  503 => 244,  499 => 243,  489 => 236,  459 => 208,  453 => 206,  447 => 204,  445 => 203,  437 => 197,  425 => 191,  421 => 190,  417 => 189,  413 => 188,  408 => 186,  404 => 185,  400 => 184,  396 => 183,  392 => 182,  388 => 181,  377 => 175,  372 => 172,  360 => 166,  356 => 165,  352 => 164,  348 => 163,  343 => 161,  339 => 160,  335 => 159,  331 => 158,  327 => 157,  323 => 156,  313 => 151,  293 => 134,  279 => 122,  275 => 120,  271 => 119,  266 => 117,  256 => 110,  251 => 107,  246 => 101,  229 => 69,  217 => 60,  213 => 59,  202 => 51,  189 => 40,  183 => 37,  179 => 36,  175 => 35,  171 => 34,  165 => 31,  162 => 30,  158 => 28,  156 => 27,  149 => 23,  145 => 22,  142 => 21,  132 => 20,  114 => 11,  104 => 10,  90 => 4,  80 => 3,  61 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}
{% block title %}Login Form{% endblock %}
{% block stylesheets %}
        <link href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css\" rel=\"stylesheet\"integrity=\"sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN\" crossorigin=\"anonymous\">
        <link rel=\"stylesheet\" href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-alpha1/dist/css/bootstrap.min.css\">
        <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css\"integrity=\"sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==\"crossorigin=\"anonymous\" referrerpolicy=\"no-referrer\" />
        <link rel=\"stylesheet\" href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-alpha1/dist/css/bootstrap.min.css\">
{% endblock %}

{% block javascripts %}
        <script src=\"https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js\"integrity=\"sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL\"crossorigin=\"anonymous\"></script>
        <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js\"></script>
        <script src=\"https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js\"></script>
        <script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js\"></script>
        <script src=\"https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-alpha1/dist/js/bootstrap.bundle.min.js\"></script>    
        <script src=\"https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js\"></script>
        <script src=\"https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-alpha1/dist/js/bootstrap.bundle.min.js\"></script>
        <script src=\"https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js\"></script>
{% endblock %}
{% block body %}

<link href=\"{{ asset('css/createdJobData.css') }}\" rel=\"stylesheet\"/>
<link href=\"{{ asset('css/userAllPosts.css') }}\" rel=\"stylesheet\"/>

        <div id=\"overlay\"></div>
        <div id=\"popup\">
            {% if posts == \"\" %}
                <div class=\"textview lgview\">Welcome! Webkul</div>
            {% else %}
            <div class=\"\">
                  <img src={{asset(posts.url)}} class=\"rounded-circle viewpic\" width=\"20px\" height=\"20px\">
                </div>             
              <div class=\"\">
                <div class=\"textview\">Name: {{posts.name}}</div>
                <div class=\"textview\">Email: {{posts.email}}</div>
                <div class=\"textview\">Location: {{posts.location}}</div>
                <div class=\"textview\">Title: {{posts.title}}</div>
              </div>
            {% endif %}
        </div>


<div class=\"body\">
    <div class=\"container-fluid p-0\">
    

        <nav class=\"navbar navbar p-0\">
        <div class=\"left\">
            <div class=\"logo\">
                <a class=\"navbar-brand \" href=\"#\">
                <img src=\"{{ asset('img/webkul_logo.png') }}\" class=\"logo\" alt=\"\">
                </a>
            </div>
            <div class=\"webkul\">
            <span class=\"logo-content\"> Webkul</span>
            </div>
        </div>
        <div class=\"nav-right\">
          <a href=\"{{path('userprofile',{'mail': mail })}}\" class=\"link1\">User Profile</a>
          <a href=\"{{path('logout')}}\" class=\"link1\" onclick=\"return logout()\">Logout</a>
        </div>
        </nav>
    </div>
    
    <div class=\"container justify-content-center\">
    
    <div class=\"row\">
      <div class=\"colomb-srch\">     
      <form method=\"post\" action=\"{{path('allPostsrch',{'mail': mail,'val': temp })}}\" class=\"search-form\">     
      <div class=\"input-group mb-3\">
         <input type=\"text\" name=\"search\" class=\"form-control input-text\" placeholder=\"Search products....\" aria-label=\"Recipient's username\" aria-describedby=\"basic-addon2\">
         <div class=\"input-group-append\">
        <button class=\"btn btn-srch btn-lg\" type=\"search\"><i class=\"fa fa-search\"></i></button>
      </div>
    </div>           
    </div>  

    </div>
    
    
</div>

{#       
        <div id=\"overlay\"></div>
        <div id=\"popup\">
            {% if posts == \"\" %}
                <div class=\"textview lgview\">Welcome! Webkul</div>
            {% else %}
            <div class=\"\">
                  <img src={{asset(posts.url)}} class=\"rounded-circle viewpic\" width=\"20px\" height=\"20px\">
                </div>             
              <div class=\"\">
                <div class=\"textview\">Name: {{posts.name}}</div>
                <div class=\"textview\">Email: {{posts.email}}</div>
                <div class=\"textview\">Location: {{posts.location}}</div>
                <div class=\"textview\">Title: {{posts.title}}</div>
              </div>
            {% endif %}
        </div>
      #}

    <div class=\"row m-0 p-0\">
      <div class=\"col-lg-3 m-0 p-0\">
        {# <div class=\"f-link\">
           <a href=\"{{path('publish',{'mail': mail })}}\" class=\"btn-a\" onclick=\"return publishpost()\">Your Publish Post</a>
        </div>    #}
       </div>
      <div class=\"col-lg-6 m-0 p-0\">
           <div class=\"m-link\">
           <div class=\"btm-para\">Users all Publish and Unpublish posts.{{pg}}</div>
           </div>   
      </div>

      <div class=\"col-lg-3 m-0 p-0\">
          <div class=\"f-link s-link\">
            <div class=\"dropdown show\">
              <a class=\"dropdwn dropdown-toggle\" href=\"#\" role=\"button\" id=\"dropdownMenuLink\" data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">{{type}}</a>
                <div class=\"dropdown-menu\" aria-labelledby=\"dropdownMenuLink\">
                   <a class=\"dropdown-item\" href=\"{{path('userallpost',{'mail': mail, 'val':1 })}}\">Publish Posts</a>
                   <a class=\"dropdown-item\" href=\"{{path('userallpost',{'mail': mail, 'val':2 })}}\">Unpublish Posts</a>
                   {# <a class=\"dropdown-item\" href=\"{{path('userallpost',{'mail': mail, 'val':3 })}}\">Publish and Unpublish Posts</a> #}
                </div>
            </div>
           </div>              
      </div>
    </div>


    



    <div class=\"div2 tag\">
    <form method=\"POST\" action=\"{{path('multidelAPosts',{'mail': mail, 'temp':temp})}}\">
    <input type=\"submit\" name=\"mul_delete\" class=\"mul-del\" value=\"Delete\" onclick=\"return mulDel()\">
      <table class=\"table1\" border=\"1\" cellSpacing=\"0\"> 
        <thead class=\"thead-dark\">
          <tr >
            <th class=\"col\" width=\"9%\"><input type=\"checkbox\" id=\"select_all\" name=\"\" value=\"\"></th>
            <th class=\"col\" width=\"9%\">Company </th>
            <th class=\"col\" width=\"16%\">Name</th>
            <th class=\"col\" width=\"20%\">Email</th>
            <th class=\"col\" width=\"12%\">Location</th>
            <th class=\"col\" width=\"15%\">Title</th>
            <th class=\"col\" width=\"19%\">Actions</th>

          </tr>
        </thead>
      </table>

      {% for job in publishJobs %}  
      <table class=\"table1 table2\" border=\"1\" cellSpacing=\"0\" >

        <tbody>
          <tr height=\"\">
            <td width=\"9%\"><input type=\"checkbox\" name=\"multiple_delete[]\" value={{job.id}} class=\"checkbox\"> </td>
            <td width=\"9%\"><img src={{asset(job.url)}} alt=\"\" class=\"img-data\"></td>
            <td width=\"16%\">{{job.name}}</td>
            <td width=\"20%\">{{job.email}}</td>
            <td width=\"12%\">{{job.location}}</td>
            <td width=\"15%\">{{job.title}}</td>
            <td width=\"19%\">
                <a href=\"{{path('delpubpost',{'id': job.id ,'mail': job.email})}}\" class=\"delete\" onclick=\"return cnfDelete();\"><i class=\"fa-solid fa-trash\"></i></a>
                <a href=\"{{path('editpostjob',{'id': job.id ,'mail': job.email})}}\" class=\"update\" onclick=\"return cnfEdit();\"><i class=\"fa-solid fa-pen\" ></i></a>
                <a href=\"{{path('userpostview',{'mail': job.email, 'val':1, 'id': job.id, 'tag':1, 'pg':pg,'page': pg})}}\" class=\"publish viewbtn\" onclick=\"return cnfView();\"><i class=\"fa-solid fa-eye\"></i></a>
                <a href=\"{{path('unpubdata',{'id': job.id ,'mail': job.email})}}\" class=\"publish\" onclick=\"return cnfUnpublish();\"><i class=\"fa-solid fa-download\"></i></a>
            </td>
          </tr>
        </tbody>
        </table>
        {% endfor %}



        {% for job in unpublishJobs %}  
         <table class=\"table1 table2\" border=\"1\" cellSpacing=\"0\" >


         <tbody>
          <tr height=\"\">
            <td width=\"9%\"><input type=\"checkbox\" name=\"multiple_delete[]\" value={{job.id}} class=\"checkbox\"> </td>
            <td width=\"9%\"><img src={{asset(job.url)}} alt=\"\" class=\"img-data\"></td>
            <td width=\"16%\">{{job.name}}</td>
            <td width=\"20%\">{{job.email}}</td>
            <td width=\"12%\">{{job.location}}</td>
            <td width=\"15%\">{{job.title}}</td>
            <td width=\"19%\">
                <a href=\"{{path('delunpubpost',{'id': job.id ,'mail': job.email})}}\" class=\"delete\" onclick=\"return cnfDelete();\"><i class=\"fa-solid fa-trash\"></i></a>
                <a href=\"{{path('editunpostjob',{'id': job.id ,'mail': job.email})}}\" class=\"update\" onclick=\"return cnfEdit();\"><i class=\"fa-solid fa-pen\" ></i></a>
                <a href=\"{{path('userpostview',{'mail': job.email, 'val':2, 'id': job.id, 'tag':1, 'pg': pg, 'page': pg})}}\" class=\"publish viewbtn\" onclick=\"cnfView();\"><i class=\"fa-solid fa-eye\"></i></a>
                <a href=\"{{path('pubdata',{'id': job.id ,'mail': job.email})}}\" class=\"publish\" onchange=\"return cnfPublish();\"><i class=\"fa-solid fa-upload\"></i></a>
            </td>
          </tr>
        </tbody>
        </table>
        {% endfor %}



        </form>
        <br>
        <div class=\"paginate\">
        {% if unpublishJobs == \"\" %}
        {{knp_pagination_render(publishJobs)}}
        {% else %}
        {{knp_pagination_render(unpublishJobs)}}
        {% endif %}
        </div>
      </div>
   </div>
</div> 

</div>

<div class=\"container-fluid p-0 mt-5\">

  <footer class=\"bg-dark text-center text-white pt-5\">
  <div class=\"container p-4 pb-0\">
    <section class=\"mb-4\">
      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-facebook-f\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-twitter\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-google\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-instagram\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-linkedin-in\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-github\"></i></a>
    </section>
  </div>

  <div class=\"text-center p-3\" style=\"background-color: rgba(0, 0, 0, 0.2);\">
    © 2020 Copyright:
    <input type=\"text\" id=\"tg\" value={{tag}} disabled>
    <a class=\"text-white\" href=\"https://webkul.com/\">webkul.com</a>
  </div>
</footer>
  
</div>

  <script src=\"{{ asset('js/createdJobData.js') }}\"></script>
  <script src=\"{{ asset('js/userAllPost.js') }}\"></script>

{% endblock %}

", "view/userAllPosts.html.twig", "/home/users/shivam.baranwal/www/html/symfony_4/templates/view/userAllPosts.html.twig");
    }
}
