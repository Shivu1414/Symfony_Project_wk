<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* view/adminProfile.html.twig */
class __TwigTemplate_fd1843f9b0728773702270373d2aa236e988067c349b0833652546a556f41ffb extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'stylesheets' => [$this, 'block_stylesheets'],
            'javascripts' => [$this, 'block_javascripts'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "view/adminProfile.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "view/adminProfile.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "view/adminProfile.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 2
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "Login Form";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 3
    public function block_stylesheets($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 4
        echo "        <link href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css\" rel=\"stylesheet\"integrity=\"sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN\" crossorigin=\"anonymous\">
        <link rel=\"stylesheet\" href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-alpha1/dist/css/bootstrap.min.css\">
        <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css\"integrity=\"sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==\"crossorigin=\"anonymous\" referrerpolicy=\"no-referrer\" />
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 9
    public function block_javascripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        // line 10
        echo "        <script src=\"https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js\"integrity=\"sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL\"crossorigin=\"anonymous\"></script>
        <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js\"></script>
        <script src=\"https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js\"></script>
        <script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js\"></script>
        <script src=\"https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-alpha1/dist/js/bootstrap.bundle.min.js\"></script>    
        <script src=\"https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js\"></script>
        <script src=\"";
        // line 16
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/adminProfile.js"), "html", null, true);
        echo "\"></script>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 19
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 20
        echo "<div class=\"body\">

<link href=\"";
        // line 22
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("css/adminProfile.css"), "html", null, true);
        echo "\" rel=\"stylesheet\"/>
<div class=\"body\">
    <div class=\"container-fluid p-0\">
        <nav class=\"navbar navbar p-0\">
        <div class=\"left\">
            <div class=\"logo\">
                <a class=\"navbar-brand \" href=\"#\">
                <img src=\"";
        // line 29
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/webkul_logo.png"), "html", null, true);
        echo "\" class=\"logo\" alt=\"\">
                </a>
            </div>
            <div class=\"webkul\">
            <span class=\"logo-content\"> Webkul</span>
            </div>
        </div>
        <div class=\"nav-right\">
          <a href=\"";
        // line 37
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("logout");
        echo "\" class=\"link1\" onclick=\"return logout()\">Logout</a>
        </div>
        </nav>
    </div>



        <div class=\"row m-5\">
      <div class=\"col-lg-2 \"></div>
      <div class=\"col-lg-8\">
           <div class=\"m-link\">
           <div class=\"btm-para\">Here are all the users of Webkul</div>
           </div>   
      </div>
      <div class=\"col-lg-2 \">
          <div class=\"f-link s-link\">
           <a href=\"";
        // line 53
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("alldeladmin");
        echo "\" class=\"btn-a\" onclick=\"return alldel()\">All Delete</a>
           </div>              
      </div>
    </div>


    <div class=\"div2 \">
    <form method=\"POST\" action=\"";
        // line 60
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("multidelUser");
        echo "\" >
    <input type=\"submit\" name=\"mul_delete\" class=\"mul-del\" value=\"Delete\" onclick=\"return mulDel()\">
      <table id=\"supact\" class=\"table1\" border=\"1\" cellSpacing=\"0\"> 

        <thead class=\"thead-dark\">
          <tr >
            <th class=\"col\" width=\"9%\"><input type=\"checkbox\" id=\"select_all\" name=\"\" value=\"\"></th>
            <th class=\"col\" width=\"15%\">Picture </th>
            <th class=\"col\" width=\"13%\">Name</th>
            <th class=\"col\" width=\"21%\">Email</th>
            <th class=\"col\" width=\"12%\">No. of Posts</th>
            <th class=\"col\" width=\"12%\">Publish Posts</th>
            <th class=\"col\" width=\"18%\">Actions</th>
          </tr>
        </thead>
      </table>

    ";
        // line 77
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["admins"]) || array_key_exists("admins", $context) ? $context["admins"] : (function () { throw new RuntimeError('Variable "admins" does not exist.', 77, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["admin"]) {
            echo "  
      <table class=\"table1 table2\" border=\"1\" cellSpacing=\"0\" >
        <tbody>
          <tr height=\"\" class=\"\">
            <td width=\"9%\"><input type=\"checkbox\" class=\"check\" name=\"multiple_delete[]\" value=";
            // line 81
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["admin"], "id", [], "any", false, false, false, 81), "html", null, true);
            echo "> </td>
            </form>

            <td width=\"15%\"><img src=";
            // line 84
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl(twig_get_attribute($this->env, $this->source, $context["admin"], "url", [], "any", false, false, false, 84)), "html", null, true);
            echo " alt=\"\" class=\"img-data\"></td>
            <td width=\"13%\">";
            // line 85
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["admin"], "firstname", [], "any", false, false, false, 85), "html", null, true);
            echo " ";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["admin"], "lastname", [], "any", false, false, false, 85), "html", null, true);
            echo "</td>
            <td width=\"21%\">";
            // line 86
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["admin"], "email", [], "any", false, false, false, 86), "html", null, true);
            echo "</td>

            <form method=\"POST\" action=\"";
            // line 88
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("activepost", ["mail" => twig_get_attribute($this->env, $this->source, $context["admin"], "email", [], "any", false, false, false, 88)]), "html", null, true);
            echo "\">
            
            <td width=\"12%\"><input type=\"submit\" name=\"activelink\" class=\"all-posts\" value=";
            // line 90
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["userPostCounts"]) || array_key_exists("userPostCounts", $context) ? $context["userPostCounts"] : (function () { throw new RuntimeError('Variable "userPostCounts" does not exist.', 90, $this->source); })()), twig_get_attribute($this->env, $this->source, $context["admin"], "id", [], "any", false, false, false, 90), [], "array", false, false, false, 90), "html", null, true);
            echo "></td>
            <td width=\"12%\"><input type=\"submit\" formaction=\"";
            // line 91
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("activePublishPost", ["mail" => twig_get_attribute($this->env, $this->source, $context["admin"], "email", [], "any", false, false, false, 91)]), "html", null, true);
            echo "\" name=\"\" class=\"all-posts\" value=";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["userPubPosts"]) || array_key_exists("userPubPosts", $context) ? $context["userPubPosts"] : (function () { throw new RuntimeError('Variable "userPubPosts" does not exist.', 91, $this->source); })()), twig_get_attribute($this->env, $this->source, $context["admin"], "id", [], "any", false, false, false, 91), [], "array", false, false, false, 91), "html", null, true);
            echo "></td>
            
            <td width=\"18%\">
                <span id=\"hinttoggle\" class=\"hint-css\">Make Link Active Or Inactive</span><br>
                <span class=\"toggle tgl\">
                <label class=\"switch\" >
                <input type=\"checkbox\" name=\"checkbox\" id=\"checkbox\" class=\"checkbox\" value=\"Active\" >
                <span class=\"slider round\" ></span>
                </label>
                </span>             
            </td>
            </form>

          </tr>
        </tbody>
     </table>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['admin'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 108
        echo "        <div class=\"paginate\">
        ";
        // line 109
        echo $this->extensions['Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension']->render($this->env, (isset($context["admins"]) || array_key_exists("admins", $context) ? $context["admins"] : (function () { throw new RuntimeError('Variable "admins" does not exist.', 109, $this->source); })()));
        echo "
        </div>
</div>



</div>
<div class=\"container-fluid p-0 mt-5\">

  <footer class=\"bg-dark text-center text-white pt-5\">
  <div class=\"container p-4 pb-0\">
    <section class=\"mb-4\">
      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-facebook-f\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-twitter\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-google\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-instagram\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-linkedin-in\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-github\"></i></a>
    </section>
  </div>

  <div class=\"text-center p-3\" style=\"background-color: rgba(0, 0, 0, 0.2);\">
    © 2020 Copyright:
    <a class=\"text-white\" href=\"https://webkul.com/\">webkul.com</a>
  </div>
</footer>
  
</div>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "view/adminProfile.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable()
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  285 => 109,  282 => 108,  257 => 91,  253 => 90,  248 => 88,  243 => 86,  237 => 85,  233 => 84,  227 => 81,  218 => 77,  198 => 60,  188 => 53,  169 => 37,  158 => 29,  148 => 22,  144 => 20,  134 => 19,  121 => 16,  113 => 10,  103 => 9,  90 => 4,  80 => 3,  61 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}
{% block title %}Login Form{% endblock %}
{% block stylesheets %}
        <link href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css\" rel=\"stylesheet\"integrity=\"sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN\" crossorigin=\"anonymous\">
        <link rel=\"stylesheet\" href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-alpha1/dist/css/bootstrap.min.css\">
        <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css\"integrity=\"sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==\"crossorigin=\"anonymous\" referrerpolicy=\"no-referrer\" />
{% endblock %}

{% block javascripts %}
        <script src=\"https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js\"integrity=\"sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL\"crossorigin=\"anonymous\"></script>
        <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js\"></script>
        <script src=\"https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js\"></script>
        <script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js\"></script>
        <script src=\"https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-alpha1/dist/js/bootstrap.bundle.min.js\"></script>    
        <script src=\"https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js\"></script>
        <script src=\"{{ asset('js/adminProfile.js') }}\"></script>

{% endblock %}
{% block body %}
<div class=\"body\">

<link href=\"{{ asset('css/adminProfile.css') }}\" rel=\"stylesheet\"/>
<div class=\"body\">
    <div class=\"container-fluid p-0\">
        <nav class=\"navbar navbar p-0\">
        <div class=\"left\">
            <div class=\"logo\">
                <a class=\"navbar-brand \" href=\"#\">
                <img src=\"{{ asset('img/webkul_logo.png') }}\" class=\"logo\" alt=\"\">
                </a>
            </div>
            <div class=\"webkul\">
            <span class=\"logo-content\"> Webkul</span>
            </div>
        </div>
        <div class=\"nav-right\">
          <a href=\"{{path('logout')}}\" class=\"link1\" onclick=\"return logout()\">Logout</a>
        </div>
        </nav>
    </div>



        <div class=\"row m-5\">
      <div class=\"col-lg-2 \"></div>
      <div class=\"col-lg-8\">
           <div class=\"m-link\">
           <div class=\"btm-para\">Here are all the users of Webkul</div>
           </div>   
      </div>
      <div class=\"col-lg-2 \">
          <div class=\"f-link s-link\">
           <a href=\"{{path('alldeladmin')}}\" class=\"btn-a\" onclick=\"return alldel()\">All Delete</a>
           </div>              
      </div>
    </div>


    <div class=\"div2 \">
    <form method=\"POST\" action=\"{{path('multidelUser')}}\" >
    <input type=\"submit\" name=\"mul_delete\" class=\"mul-del\" value=\"Delete\" onclick=\"return mulDel()\">
      <table id=\"supact\" class=\"table1\" border=\"1\" cellSpacing=\"0\"> 

        <thead class=\"thead-dark\">
          <tr >
            <th class=\"col\" width=\"9%\"><input type=\"checkbox\" id=\"select_all\" name=\"\" value=\"\"></th>
            <th class=\"col\" width=\"15%\">Picture </th>
            <th class=\"col\" width=\"13%\">Name</th>
            <th class=\"col\" width=\"21%\">Email</th>
            <th class=\"col\" width=\"12%\">No. of Posts</th>
            <th class=\"col\" width=\"12%\">Publish Posts</th>
            <th class=\"col\" width=\"18%\">Actions</th>
          </tr>
        </thead>
      </table>

    {% for admin in admins %}  
      <table class=\"table1 table2\" border=\"1\" cellSpacing=\"0\" >
        <tbody>
          <tr height=\"\" class=\"\">
            <td width=\"9%\"><input type=\"checkbox\" class=\"check\" name=\"multiple_delete[]\" value={{admin.id}}> </td>
            </form>

            <td width=\"15%\"><img src={{asset(admin.url)}} alt=\"\" class=\"img-data\"></td>
            <td width=\"13%\">{{admin.firstname}} {{admin.lastname}}</td>
            <td width=\"21%\">{{admin.email}}</td>

            <form method=\"POST\" action=\"{{path('activepost',{'mail':admin.email})}}\">
            
            <td width=\"12%\"><input type=\"submit\" name=\"activelink\" class=\"all-posts\" value={{userPostCounts[admin.id]}}></td>
            <td width=\"12%\"><input type=\"submit\" formaction=\"{{path('activePublishPost',{'mail':admin.email})}}\" name=\"\" class=\"all-posts\" value={{userPubPosts[admin.id]}}></td>
            
            <td width=\"18%\">
                <span id=\"hinttoggle\" class=\"hint-css\">Make Link Active Or Inactive</span><br>
                <span class=\"toggle tgl\">
                <label class=\"switch\" >
                <input type=\"checkbox\" name=\"checkbox\" id=\"checkbox\" class=\"checkbox\" value=\"Active\" >
                <span class=\"slider round\" ></span>
                </label>
                </span>             
            </td>
            </form>

          </tr>
        </tbody>
     </table>
    {% endfor %}
        <div class=\"paginate\">
        {{knp_pagination_render(admins)}}
        </div>
</div>



</div>
<div class=\"container-fluid p-0 mt-5\">

  <footer class=\"bg-dark text-center text-white pt-5\">
  <div class=\"container p-4 pb-0\">
    <section class=\"mb-4\">
      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-facebook-f\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-twitter\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-google\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-instagram\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-linkedin-in\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-github\"></i></a>
    </section>
  </div>

  <div class=\"text-center p-3\" style=\"background-color: rgba(0, 0, 0, 0.2);\">
    © 2020 Copyright:
    <a class=\"text-white\" href=\"https://webkul.com/\">webkul.com</a>
  </div>
</footer>
  
</div>

{% endblock %}", "view/adminProfile.html.twig", "/home/users/shivam.baranwal/www/html/symfony_4/templates/view/adminProfile.html.twig");
    }
}
