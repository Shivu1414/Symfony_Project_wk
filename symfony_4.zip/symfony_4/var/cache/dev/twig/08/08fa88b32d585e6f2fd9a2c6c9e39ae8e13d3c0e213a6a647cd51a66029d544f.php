<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* view/viewpublishPost.html.twig */
class __TwigTemplate_3deff0597a2a2a6db5c508a92c9c93d71d73254bfe1ebaed4471e72faf3c8885 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'stylesheets' => [$this, 'block_stylesheets'],
            'javascripts' => [$this, 'block_javascripts'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "view/viewpublishPost.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "view/viewpublishPost.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "view/viewpublishPost.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 2
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "Login Form";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 3
    public function block_stylesheets($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 4
        echo "        <link href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css\" rel=\"stylesheet\"integrity=\"sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN\" crossorigin=\"anonymous\">
        <link rel=\"stylesheet\" href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-alpha1/dist/css/bootstrap.min.css\">
        <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css\"integrity=\"sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==\"crossorigin=\"anonymous\" referrerpolicy=\"no-referrer\" />
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 9
    public function block_javascripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        // line 10
        echo "        <script src=\"https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js\"integrity=\"sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL\"crossorigin=\"anonymous\"></script>
        <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js\"></script>
        <script src=\"https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js\"></script>
        <script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js\"></script>
        <script src=\"https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-alpha1/dist/js/bootstrap.bundle.min.js\"></script>    
        <script src=\"https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js\"></script>
        <script src=\"";
        // line 16
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/userposts.js"), "html", null, true);
        echo "\"></script>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 19
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 20
        echo "<link href=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("css/userposts.css"), "html", null, true);
        echo "\" rel=\"stylesheet\"/>
<div class=\"body\">

  <div class=\"body\">    
    <div class=\"container-fluid p-0\">
        <nav class=\"navbar navbar p-0\">
          <div class=\"nav-left\">
            <div>
            <a class=\"p-0\" href=\"#\">
                <img src=\"";
        // line 29
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/webkul_logo.png"), "html", null, true);
        echo "\" class=\"logo\" alt=\"\">
            </a>
            </div>
            <div class=\"\">
            <span class=\"logo-content\"> Webkul</span>
            </div>
          </div>
          <div class=\"nav-right\">
          <a href=\"";
        // line 37
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("adminProfile");
        echo "\" class=\"link1\">Admin Profile</a>
          <a href=\"";
        // line 38
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("logout");
        echo "\" class=\"link1\" onclick=\"return logout()\">Logout</a>
          </div>
        </nav>
    </div>


    <div class=\"row m-5\">
      <div class=\"col-lg-2 \">
        <!-- <div class=\"f-link\">
           <a href=\"../view/viewPublish.php?id=<?php ?> & mail=<?php ?>\" class=\"btn-a\" onclick=\"return publishpost()\">User Publish Post</a>
        </div>    -->
       </div>
      <div class=\"col-lg-8\">
           <div class=\"m-link\">
           <div class=\"btm-para\">You can delete User post only here.</div>
           </div>   
      </div>
      <div class=\"col-lg-2 \">
          <div class=\"f-link s-link\">
           <a href=\"";
        // line 57
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("alldelPubActiveData", ["mail" => (isset($context["mail"]) || array_key_exists("mail", $context) ? $context["mail"] : (function () { throw new RuntimeError('Variable "mail" does not exist.', 57, $this->source); })())]), "html", null, true);
        echo "\" class=\"btn-a\" onclick=\"return alldel()\">All Delete</a>
           </div>              
      </div>
    </div>



    <div class=\"div2 \">
    <form method=\"POST\" action=\"";
        // line 65
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("muldelActivePubData", ["mail" => (isset($context["mail"]) || array_key_exists("mail", $context) ? $context["mail"] : (function () { throw new RuntimeError('Variable "mail" does not exist.', 65, $this->source); })())]), "html", null, true);
        echo "\">
    <input type=\"submit\" name=\"mul-del\" class=\"mul-del\" value=\"Delete\" onclick=\"return mulDel()\"> 
      <table class=\"table1\" border=\"1\" cellSpacing=\"0\"> 

        <thead class=\"thead-dark\">
          <tr >
            <th class=\"col\" width=\"9%\"><input type=\"checkbox\" id=\"select_all\" name=\"\" value=\"\"></th>
            <th class=\"col\" width=\"9%\">Company </th>
            <th class=\"col\" width=\"16%\">Name</th>
            <th class=\"col\" width=\"20%\">Email</th>
            <th class=\"col\" width=\"12%\">Location</th>
            <th class=\"col\" width=\"20%\">Title</th>
            <th class=\"col\" width=\"15%\">Actions</th>
          </tr>
        </thead>
      </table>
       
     ";
        // line 82
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["jobs"]) || array_key_exists("jobs", $context) ? $context["jobs"] : (function () { throw new RuntimeError('Variable "jobs" does not exist.', 82, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["job"]) {
            echo "  
      <table class=\"table1 table2\" border=\"1\" cellSpacing=\"0\">
        <tbody>
          <tr height=\"\">
            <td width=\"9%\"><input type=\"checkbox\" class=\"checkbox\" name=\"multiple_delete[]\" value=";
            // line 86
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["job"], "id", [], "any", false, false, false, 86), "html", null, true);
            echo "></td>
            <td width=\"9%\"><img src=";
            // line 87
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl(twig_get_attribute($this->env, $this->source, $context["job"], "url", [], "any", false, false, false, 87)), "html", null, true);
            echo " alt=\"\" class=\"img-data\"></td>
            <td width=\"16%\">";
            // line 88
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["job"], "name", [], "any", false, false, false, 88), "html", null, true);
            echo "</td>
            <td width=\"20%\">";
            // line 89
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["job"], "email", [], "any", false, false, false, 89), "html", null, true);
            echo "</td>
            <td width=\"12%\">";
            // line 90
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["job"], "location", [], "any", false, false, false, 90), "html", null, true);
            echo "</td>
            <td width=\"20%\">";
            // line 91
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["job"], "title", [], "any", false, false, false, 91), "html", null, true);
            echo "</td>
            <td width=\"15%\">
                <a href=\"";
            // line 93
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("delActivePubData", ["id" => twig_get_attribute($this->env, $this->source, $context["job"], "id", [], "any", false, false, false, 93), "mail" => twig_get_attribute($this->env, $this->source, $context["job"], "email", [], "any", false, false, false, 93)]), "html", null, true);
            echo "\" class=\"delete\" onclick=\"return cnfDelete();\"><i class=\"fa-solid fa-trash\"></i></a>
                <a href=\"";
            // line 94
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("editActivePubPost", ["id" => twig_get_attribute($this->env, $this->source, $context["job"], "id", [], "any", false, false, false, 94), "mail" => twig_get_attribute($this->env, $this->source, $context["job"], "email", [], "any", false, false, false, 94)]), "html", null, true);
            echo "\" class=\"update\" onclick=\"return cnfEdit();\"><i class=\"fa-solid fa-pen\" ></i></a>
                <a href=\"";
            // line 95
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("auserUnpub", ["id" => twig_get_attribute($this->env, $this->source, $context["job"], "id", [], "any", false, false, false, 95), "mail" => twig_get_attribute($this->env, $this->source, $context["job"], "email", [], "any", false, false, false, 95)]), "html", null, true);
            echo "\" class=\"publish\" onclick=\"return cnfPublish();\"><i class=\"fa-solid fa-download\"></i></a>
            </td>
          </tr>
        </tbody>
        </table>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['job'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 101
        echo "        <div class=\"paginate\">
        ";
        // line 102
        echo $this->extensions['Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension']->render($this->env, (isset($context["jobs"]) || array_key_exists("jobs", $context) ? $context["jobs"] : (function () { throw new RuntimeError('Variable "jobs" does not exist.', 102, $this->source); })()));
        echo "
        </div>

        </form>
        </div>
    </div>
</div> 

</div>
<div class=\"container-fluid p-0 mt-5\">

  <footer class=\"bg-dark text-center text-white pt-5\">
  <div class=\"container p-4 pb-0\">
    <section class=\"mb-4\">
      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-facebook-f\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-twitter\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-google\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-instagram\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-linkedin-in\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-github\"></i></a>
    </section>
  </div>

  <div class=\"text-center p-3\" style=\"background-color: rgba(0, 0, 0, 0.2);\">
    © 2020 Copyright:
    <a class=\"text-white\" href=\"https://webkul.com/\">webkul.com</a>
  </div>
</footer>
  
</div>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "view/viewpublishPost.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable()
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  282 => 102,  279 => 101,  267 => 95,  263 => 94,  259 => 93,  254 => 91,  250 => 90,  246 => 89,  242 => 88,  238 => 87,  234 => 86,  225 => 82,  205 => 65,  194 => 57,  172 => 38,  168 => 37,  157 => 29,  144 => 20,  134 => 19,  121 => 16,  113 => 10,  103 => 9,  90 => 4,  80 => 3,  61 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}
{% block title %}Login Form{% endblock %}
{% block stylesheets %}
        <link href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css\" rel=\"stylesheet\"integrity=\"sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN\" crossorigin=\"anonymous\">
        <link rel=\"stylesheet\" href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-alpha1/dist/css/bootstrap.min.css\">
        <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css\"integrity=\"sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==\"crossorigin=\"anonymous\" referrerpolicy=\"no-referrer\" />
{% endblock %}

{% block javascripts %}
        <script src=\"https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js\"integrity=\"sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL\"crossorigin=\"anonymous\"></script>
        <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js\"></script>
        <script src=\"https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js\"></script>
        <script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js\"></script>
        <script src=\"https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-alpha1/dist/js/bootstrap.bundle.min.js\"></script>    
        <script src=\"https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js\"></script>
        <script src=\"{{ asset('js/userposts.js') }}\"></script>

{% endblock %}
{% block body %}
<link href=\"{{ asset('css/userposts.css') }}\" rel=\"stylesheet\"/>
<div class=\"body\">

  <div class=\"body\">    
    <div class=\"container-fluid p-0\">
        <nav class=\"navbar navbar p-0\">
          <div class=\"nav-left\">
            <div>
            <a class=\"p-0\" href=\"#\">
                <img src=\"{{ asset('img/webkul_logo.png') }}\" class=\"logo\" alt=\"\">
            </a>
            </div>
            <div class=\"\">
            <span class=\"logo-content\"> Webkul</span>
            </div>
          </div>
          <div class=\"nav-right\">
          <a href=\"{{path('adminProfile')}}\" class=\"link1\">Admin Profile</a>
          <a href=\"{{path('logout')}}\" class=\"link1\" onclick=\"return logout()\">Logout</a>
          </div>
        </nav>
    </div>


    <div class=\"row m-5\">
      <div class=\"col-lg-2 \">
        <!-- <div class=\"f-link\">
           <a href=\"../view/viewPublish.php?id=<?php ?> & mail=<?php ?>\" class=\"btn-a\" onclick=\"return publishpost()\">User Publish Post</a>
        </div>    -->
       </div>
      <div class=\"col-lg-8\">
           <div class=\"m-link\">
           <div class=\"btm-para\">You can delete User post only here.</div>
           </div>   
      </div>
      <div class=\"col-lg-2 \">
          <div class=\"f-link s-link\">
           <a href=\"{{path('alldelPubActiveData',{'mail': mail})}}\" class=\"btn-a\" onclick=\"return alldel()\">All Delete</a>
           </div>              
      </div>
    </div>



    <div class=\"div2 \">
    <form method=\"POST\" action=\"{{path('muldelActivePubData',{'mail': mail})}}\">
    <input type=\"submit\" name=\"mul-del\" class=\"mul-del\" value=\"Delete\" onclick=\"return mulDel()\"> 
      <table class=\"table1\" border=\"1\" cellSpacing=\"0\"> 

        <thead class=\"thead-dark\">
          <tr >
            <th class=\"col\" width=\"9%\"><input type=\"checkbox\" id=\"select_all\" name=\"\" value=\"\"></th>
            <th class=\"col\" width=\"9%\">Company </th>
            <th class=\"col\" width=\"16%\">Name</th>
            <th class=\"col\" width=\"20%\">Email</th>
            <th class=\"col\" width=\"12%\">Location</th>
            <th class=\"col\" width=\"20%\">Title</th>
            <th class=\"col\" width=\"15%\">Actions</th>
          </tr>
        </thead>
      </table>
       
     {% for job in jobs %}  
      <table class=\"table1 table2\" border=\"1\" cellSpacing=\"0\">
        <tbody>
          <tr height=\"\">
            <td width=\"9%\"><input type=\"checkbox\" class=\"checkbox\" name=\"multiple_delete[]\" value={{job.id}}></td>
            <td width=\"9%\"><img src={{asset(job.url)}} alt=\"\" class=\"img-data\"></td>
            <td width=\"16%\">{{job.name}}</td>
            <td width=\"20%\">{{job.email}}</td>
            <td width=\"12%\">{{job.location}}</td>
            <td width=\"20%\">{{job.title}}</td>
            <td width=\"15%\">
                <a href=\"{{path('delActivePubData',{'id': job.id ,'mail': job.email})}}\" class=\"delete\" onclick=\"return cnfDelete();\"><i class=\"fa-solid fa-trash\"></i></a>
                <a href=\"{{path('editActivePubPost',{'id': job.id ,'mail': job.email})}}\" class=\"update\" onclick=\"return cnfEdit();\"><i class=\"fa-solid fa-pen\" ></i></a>
                <a href=\"{{path('auserUnpub',{'id': job.id ,'mail': job.email})}}\" class=\"publish\" onclick=\"return cnfPublish();\"><i class=\"fa-solid fa-download\"></i></a>
            </td>
          </tr>
        </tbody>
        </table>
        {% endfor %}
        <div class=\"paginate\">
        {{knp_pagination_render(jobs)}}
        </div>

        </form>
        </div>
    </div>
</div> 

</div>
<div class=\"container-fluid p-0 mt-5\">

  <footer class=\"bg-dark text-center text-white pt-5\">
  <div class=\"container p-4 pb-0\">
    <section class=\"mb-4\">
      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-facebook-f\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-twitter\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-google\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-instagram\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-linkedin-in\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-github\"></i></a>
    </section>
  </div>

  <div class=\"text-center p-3\" style=\"background-color: rgba(0, 0, 0, 0.2);\">
    © 2020 Copyright:
    <a class=\"text-white\" href=\"https://webkul.com/\">webkul.com</a>
  </div>
</footer>
  
</div>

{% endblock %}
", "view/viewpublishPost.html.twig", "/home/users/shivam.baranwal/www/html/symfony_4/templates/view/viewpublishPost.html.twig");
    }
}
