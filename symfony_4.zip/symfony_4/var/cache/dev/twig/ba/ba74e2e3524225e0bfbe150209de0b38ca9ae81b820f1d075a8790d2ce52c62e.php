<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* view/profileEdit.html.twig */
class __TwigTemplate_79df15ad0bf2232f6f94acf772c11259c056d2a9d715e5c3b1eb7ca1500bce7c extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'stylesheets' => [$this, 'block_stylesheets'],
            'javascripts' => [$this, 'block_javascripts'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "view/profileEdit.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "view/profileEdit.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "view/profileEdit.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 2
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "Login Form";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 3
    public function block_stylesheets($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 4
        echo "        <link href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css\" rel=\"stylesheet\"integrity=\"sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN\" crossorigin=\"anonymous\">
        <link rel=\"stylesheet\" href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-alpha1/dist/css/bootstrap.min.css\">
        <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css\"integrity=\"sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==\"crossorigin=\"anonymous\" referrerpolicy=\"no-referrer\" />
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 9
    public function block_javascripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        // line 10
        echo "        <script src=\"https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js\"integrity=\"sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL\"crossorigin=\"anonymous\"></script>
        <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js\"></script>
        <script src=\"https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js\"></script>
        <script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js\"></script>
        <script src=\"https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-alpha1/dist/js/bootstrap.bundle.min.js\"></script>    
        <script src=\"https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js\"></script>
        <script src=\"";
        // line 16
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/profileEdit.js"), "html", null, true);
        echo "\"></script>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 19
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 20
        echo "
<link href=\"";
        // line 21
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("css/profileEdit.css"), "html", null, true);
        echo "\" rel=\"stylesheet\"/>

    <div class=\"container-fluid p-0\">
        <nav class=\"navbar navbar p-0\">
            <a class=\"navbar-brand \" href=\"#\">
                <img src=\"";
        // line 26
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/webkul_logo.png"), "html", null, true);
        echo "\" class=\"logo\" alt=\"\"><span class=\"logo-content\"> Webkul</span>
            </a>
        </nav>
    </div>



    <div class=\"container rounded bg-white mt-2 mb-5\">
        <div class=\"row\">

            <div class=\"col-md-3 border-right\">
                <div class=\"d-flex flex-column align-items-center text-center p-3 py-5\">
                    <span class=\"head1\">Hello ";
        // line 38
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["profile"]) || array_key_exists("profile", $context) ? $context["profile"] : (function () { throw new RuntimeError('Variable "profile" does not exist.', 38, $this->source); })()), "firstname", [], "any", false, false, false, 38), "html", null, true);
        echo "</span>
                    <img class=\"rounded-circle mt-5\" width=\"200px\" src=";
        // line 39
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl(twig_get_attribute($this->env, $this->source, (isset($context["profile"]) || array_key_exists("profile", $context) ? $context["profile"] : (function () { throw new RuntimeError('Variable "profile" does not exist.', 39, $this->source); })()), "url", [], "any", false, false, false, 39)), "html", null, true);
        echo ">
                    <span class=\"font-weight-bold mt-3\">
                    ";
        // line 41
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["profile"]) || array_key_exists("profile", $context) ? $context["profile"] : (function () { throw new RuntimeError('Variable "profile" does not exist.', 41, $this->source); })()), "firstname", [], "any", false, false, false, 41), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["profile"]) || array_key_exists("profile", $context) ? $context["profile"] : (function () { throw new RuntimeError('Variable "profile" does not exist.', 41, $this->source); })()), "lastname", [], "any", false, false, false, 41), "html", null, true);
        echo "
                    </span>
                    <span class=\"text-black-50\">
                    ";
        // line 44
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["profile"]) || array_key_exists("profile", $context) ? $context["profile"] : (function () { throw new RuntimeError('Variable "profile" does not exist.', 44, $this->source); })()), "email", [], "any", false, false, false, 44), "html", null, true);
        echo "
                    </span>
                    <span> </span>
                </div>
            </div>
            <div class=\"col-md-5 border-right\">
                <div class=\"p-3 py-5\">
                    <div class=\"d-flex justify-content-between align-items-center mb-3\">
                        <h4 class=\"text-right\">Edit Profile</h4>
                    </div>

                    <form method=\"post\" action=\"";
        // line 55
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("EditProfileData", ["id" => twig_get_attribute($this->env, $this->source, (isset($context["profile"]) || array_key_exists("profile", $context) ? $context["profile"] : (function () { throw new RuntimeError('Variable "profile" does not exist.', 55, $this->source); })()), "id", [], "any", false, false, false, 55)]), "html", null, true);
        echo "\" enctype=\"multipart/form-data\" onsubmit=\"return cnfRegister()\">
                    <div class=\"row mt-2\">
                         <div class=\"col-md-6\">
                            <label class=\"labels\">First Name:</label>
                            <span class=\"error req-fd\" id=\"nameHint\">*</span>
                            <span id=\"okname\" class=\"status ok-g hcn\"><i class=\"fa-regular fa-circle-check\"></i></span>
                            <span id=\"unokname\" class=\"status unok-r hcn\"><i class=\"fa-regular fa-circle-xmark\"></i></span>
                            <span id=\"hintn\" class=\"hint-css\"></span>       
                            <input type=\"text\" name=\"fname\" class=\"form-control\" id=\"nameVal\" placeholder=\"first name\" value=\"";
        // line 63
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["profile"]) || array_key_exists("profile", $context) ? $context["profile"] : (function () { throw new RuntimeError('Variable "profile" does not exist.', 63, $this->source); })()), "firstname", [], "any", false, false, false, 63), "html", null, true);
        echo "\">
                        </div>

                         <div class=\"col-md-6\">
                            <label class=\"labels\">Last Name:</label>
                            <span class=\"error req-fd\" id=\"namelHint\">*</span>
                            <span id=\"oklname\" class=\"status ok-g hcln\"><i class=\"fa-regular fa-circle-check\"></i></span>
                             <span id=\"unoklname\" class=\"status unok-r hcln\"><i class=\"fa-regular fa-circle-xmark\"></i></span>
                             <span id=\"hintln\" class=\"hint-css\"></span>
                            <input type=\"text\" name=\"lname\" class=\"form-control\" id=\"lnameVal\" value=\"";
        // line 72
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["profile"]) || array_key_exists("profile", $context) ? $context["profile"] : (function () { throw new RuntimeError('Variable "profile" does not exist.', 72, $this->source); })()), "lastname", [], "any", false, false, false, 72), "html", null, true);
        echo "\" placeholder=\"surname\">
                        </div>
                    </div>


                    <div class=\"row mt-3\">
                        <div class=\"col-md-12\">
                            <label class=\"labels\">Email ID:</label>
                            <span class=\"error req-fd\" id=\"emailHint\">*</span>
                            <span id=\"okmail\" class=\"status ok-g hcm\"><i class=\"fa-regular fa-circle-check\"></i></span>
                            <span id=\"unokmail\" class=\"status unok-r hcm\"><i class=\"fa-regular fa-circle-xmark\"></i></span>
                            <span id=\"hintm\" class=\"hint-css\"></span>
                            <input type=\"text\" name=\"email\" class=\"form-control\" id=\"emailVal\" placeholder=\"enter email id\" value=\"";
        // line 84
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["profile"]) || array_key_exists("profile", $context) ? $context["profile"] : (function () { throw new RuntimeError('Variable "profile" does not exist.', 84, $this->source); })()), "email", [], "any", false, false, false, 84), "html", null, true);
        echo "\">
                        </div>


                        <div class=\"col-md-12\">
                            <label class=\"labels\">Mobile Number:</label>
                            <span class=\"error req-fd\" id=\"phnHint\">*</span>
                            <span id=\"okphn\" class=\"status ok-g hcph\"><i class=\"fa-regular fa-circle-check\"></i></span>
                           <span id=\"unokphn\" class=\"status unok-r hcph\"><i class=\"fa-regular fa-circle-xmark\"></i></span>
                           <span id=\"hintphn\" class=\"hint-css\"></span>
                            <input type=\"text\" name=\"phone\" class=\"form-control\" id=\"phnVal\" placeholder=\"enter phone number\" value=\"";
        // line 94
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["profile"]) || array_key_exists("profile", $context) ? $context["profile"] : (function () { throw new RuntimeError('Variable "profile" does not exist.', 94, $this->source); })()), "phone", [], "any", false, false, false, 94), "html", null, true);
        echo "\">
                        </div>
                        
                        
                        
                        <div class=\"col-md-12\">
                            <label class=\"labels\">User Address:</label>
                            <span class=\"error req-fd\" id=\"titleHint\">*</span>
                           <span id=\"okadd\" class=\"status ok-g hadd\"><i class=\"fa-regular fa-circle-check\"></i></span>
                           <span id=\"unokadd\" class=\"status unok-r hadd\"><i class=\"fa-regular fa-circle-xmark\"></i></span>
                            <span id=\"hintadd\" class=\"hint-css-p\"></span>
                            <input type=\"text\" name=\"address\" class=\"form-control\" id=\"haddress\" placeholder=\"enter address \" value=\"";
        // line 105
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["profile"]) || array_key_exists("profile", $context) ? $context["profile"] : (function () { throw new RuntimeError('Variable "profile" does not exist.', 105, $this->source); })()), "address", [], "any", false, false, false, 105), "html", null, true);
        echo "\">
                        </div>
                        
                        
                        <div class=\"col-md-12\">
                            <label class=\"labels\">Postcode:</label>
                            <span class=\"error req-fd\" id=\"pinHint\">*</span>
                           <span id=\"okpin\" class=\"status ok-g hpin\"><i class=\"fa-regular fa-circle-check\"></i></span>
                           <span id=\"unokpin\" class=\"status unok-r hpin\"><i class=\"fa-regular fa-circle-xmark\"></i></span>
                           <span id=\"hintpin\" class=\"hint-css\"></span>
                            <input type=\"text\" name=\"pincode\" id=\"pinVal\" class=\"form-control\" placeholder=\"enter pincode\" value=\"";
        // line 115
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["profile"]) || array_key_exists("profile", $context) ? $context["profile"] : (function () { throw new RuntimeError('Variable "profile" does not exist.', 115, $this->source); })()), "pincode", [], "any", false, false, false, 115), "html", null, true);
        echo "\">
                        </div>
                        
                        <div class=\"col-md-12\">
                            <label class=\"labels\">State:</label><input type=\"text\" name=\"state\" class=\"form-control\" placeholder=\"state\" value=\"";
        // line 119
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["profile"]) || array_key_exists("profile", $context) ? $context["profile"] : (function () { throw new RuntimeError('Variable "profile" does not exist.', 119, $this->source); })()), "state", [], "any", false, false, false, 119), "html", null, true);
        echo "\">
                        </div>


                    </div>
                    <div class=\"row mt-3\">
                        <div class=\"col-md-6\"><label class=\"labels\">Country</label><input name=\"country\" type=\"text\" class=\"form-control\" placeholder=\"country\" value=\"";
        // line 125
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["profile"]) || array_key_exists("profile", $context) ? $context["profile"] : (function () { throw new RuntimeError('Variable "profile" does not exist.', 125, $this->source); })()), "country", [], "any", false, false, false, 125), "html", null, true);
        echo "\"></div>
                        <div class=\"col-md-6\"><label class=\"labels\">State/Region</label><input name=\"city\" type=\"text\" class=\"form-control\" value=\"";
        // line 126
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["profile"]) || array_key_exists("profile", $context) ? $context["profile"] : (function () { throw new RuntimeError('Variable "profile" does not exist.', 126, $this->source); })()), "city", [], "any", false, false, false, 126), "html", null, true);
        echo "\" placeholder=\"city\"></div>
                    </div>
                    <div class=\"row mt-3\">
                        <div class=\"col-md-12\"><label class=\"labels\">Gender:</label><input type=\"text\" name=\"gender\" class=\"form-control\" placeholder=\"gender\" value=\"";
        // line 129
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["profile"]) || array_key_exists("profile", $context) ? $context["profile"] : (function () { throw new RuntimeError('Variable "profile" does not exist.', 129, $this->source); })()), "gender", [], "any", false, false, false, 129), "html", null, true);
        echo "\" ></div>                   
                    </div>

                    <div class=\"mt-4 text-center\"><input type=\"submit\" name=\"submit\" value=\"Save Profile\" class=\"btn btn-primary profile-button\" onclick=\"return cnfRgr()\"></div>

                </div>
            </div>

 

            <div class=\"col-md-4 mt-3\">
                <a href=\"";
        // line 140
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("logout");
        echo "\"><input type=\"button\" name=\"submit\"  value=\"LOGOUT\" class=\"preview\" onclick=\"return logout()\"></a>
               
                <div class=\"p-3 py-5 \">
                   <div class=\"col-md-12\">
                            <label class=\"labels\">About Mr. ";
        // line 144
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["profile"]) || array_key_exists("profile", $context) ? $context["profile"] : (function () { throw new RuntimeError('Variable "profile" does not exist.', 144, $this->source); })()), "firstname", [], "any", false, false, false, 144), "html", null, true);
        echo ":</label>
                            <span class=\"error req-fd\" id=\"titleHint\">*</span>
                           <span id=\"okabout\" class=\"status ok-g habt\"><i class=\"fa-regular fa-circle-check\"></i></span>
                          <span id=\"unokabout\" class=\"status unok-r habt\"><i class=\"fa-regular fa-circle-xmark\"></i></span>
                            <span id=\"hintabout\" class=\"hint-css-p\"></span>
                            <input type=\"text\" name=\"about\" class=\"form-control\" id=\"habout\"  placeholder=\"about your self\" value=\"";
        // line 149
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["profile"]) || array_key_exists("profile", $context) ? $context["profile"] : (function () { throw new RuntimeError('Variable "profile" does not exist.', 149, $this->source); })()), "about", [], "any", false, false, false, 149), "html", null, true);
        echo "\">
                    </div> 
                    <br>

                    <div class=\"form-content\">
                        <label for=\"fileToUpload\" class=\"up-img\">Upload Image</label>
                         <input type=\"file\" name=\"fileToUpload\" id=\"fileToUpload\" value=";
        // line 155
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["profile"]) || array_key_exists("profile", $context) ? $context["profile"] : (function () { throw new RuntimeError('Variable "profile" does not exist.', 155, $this->source); })()), "url", [], "any", false, false, false, 155), "html", null, true);
        echo " class=\"upload-img bg-success\" >   <br>
                         <span class=\"error req-fd req-txt\" id=\"imgHint\">*IMG Size less than 500KB and Ext: jpg, png, jpeg
                         </span><br>
                         <span id=\"okimg\" class=\"status ok-g himg\"><i class=\"fa-regular fa-circle-check\"></i></span>
                         <span id=\"unokimg\" class=\"status unok-r himg\"><i class=\"fa-regular fa-circle-xmark\"></i></span>
                         <span id=\"hintimg\" class=\"hint-css-p\"></span>       
                    </div>

                </div>

            </div>

        </div>
    </div>
    </div>
    </div>
</form>




<div class=\"container-fluid p-0 mt-5\">

  <footer class=\"bg-dark text-center text-white pt-5\">
  <div class=\"container p-4 pb-0\">
    <section class=\"mb-4\">
      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-facebook-f\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-twitter\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-google\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-instagram\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-linkedin-in\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-github\"></i></a>
    </section>
  </div>

  <div class=\"text-center p-3\" style=\"background-color: rgba(0, 0, 0, 0.2);\">
    © 2020 Copyright:
    <a class=\"text-white\" href=\"https://webkul.com/\">webkul.com</a>
  </div>
</footer>
  
</div>


";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "view/profileEdit.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable()
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  343 => 155,  334 => 149,  326 => 144,  319 => 140,  305 => 129,  299 => 126,  295 => 125,  286 => 119,  279 => 115,  266 => 105,  252 => 94,  239 => 84,  224 => 72,  212 => 63,  201 => 55,  187 => 44,  179 => 41,  174 => 39,  170 => 38,  155 => 26,  147 => 21,  144 => 20,  134 => 19,  121 => 16,  113 => 10,  103 => 9,  90 => 4,  80 => 3,  61 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}
{% block title %}Login Form{% endblock %}
{% block stylesheets %}
        <link href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css\" rel=\"stylesheet\"integrity=\"sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN\" crossorigin=\"anonymous\">
        <link rel=\"stylesheet\" href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-alpha1/dist/css/bootstrap.min.css\">
        <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css\"integrity=\"sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==\"crossorigin=\"anonymous\" referrerpolicy=\"no-referrer\" />
{% endblock %}

{% block javascripts %}
        <script src=\"https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js\"integrity=\"sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL\"crossorigin=\"anonymous\"></script>
        <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js\"></script>
        <script src=\"https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js\"></script>
        <script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js\"></script>
        <script src=\"https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-alpha1/dist/js/bootstrap.bundle.min.js\"></script>    
        <script src=\"https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js\"></script>
        <script src=\"{{ asset('js/profileEdit.js') }}\"></script>

{% endblock %}
{% block body %}

<link href=\"{{ asset('css/profileEdit.css') }}\" rel=\"stylesheet\"/>

    <div class=\"container-fluid p-0\">
        <nav class=\"navbar navbar p-0\">
            <a class=\"navbar-brand \" href=\"#\">
                <img src=\"{{ asset('img/webkul_logo.png') }}\" class=\"logo\" alt=\"\"><span class=\"logo-content\"> Webkul</span>
            </a>
        </nav>
    </div>



    <div class=\"container rounded bg-white mt-2 mb-5\">
        <div class=\"row\">

            <div class=\"col-md-3 border-right\">
                <div class=\"d-flex flex-column align-items-center text-center p-3 py-5\">
                    <span class=\"head1\">Hello {{profile.firstname}}</span>
                    <img class=\"rounded-circle mt-5\" width=\"200px\" src={{asset(profile.url)}}>
                    <span class=\"font-weight-bold mt-3\">
                    {{profile.firstname}} {{profile.lastname}}
                    </span>
                    <span class=\"text-black-50\">
                    {{profile.email}}
                    </span>
                    <span> </span>
                </div>
            </div>
            <div class=\"col-md-5 border-right\">
                <div class=\"p-3 py-5\">
                    <div class=\"d-flex justify-content-between align-items-center mb-3\">
                        <h4 class=\"text-right\">Edit Profile</h4>
                    </div>

                    <form method=\"post\" action=\"{{path('EditProfileData',{'id': profile.id})}}\" enctype=\"multipart/form-data\" onsubmit=\"return cnfRegister()\">
                    <div class=\"row mt-2\">
                         <div class=\"col-md-6\">
                            <label class=\"labels\">First Name:</label>
                            <span class=\"error req-fd\" id=\"nameHint\">*</span>
                            <span id=\"okname\" class=\"status ok-g hcn\"><i class=\"fa-regular fa-circle-check\"></i></span>
                            <span id=\"unokname\" class=\"status unok-r hcn\"><i class=\"fa-regular fa-circle-xmark\"></i></span>
                            <span id=\"hintn\" class=\"hint-css\"></span>       
                            <input type=\"text\" name=\"fname\" class=\"form-control\" id=\"nameVal\" placeholder=\"first name\" value=\"{{profile.firstname}}\">
                        </div>

                         <div class=\"col-md-6\">
                            <label class=\"labels\">Last Name:</label>
                            <span class=\"error req-fd\" id=\"namelHint\">*</span>
                            <span id=\"oklname\" class=\"status ok-g hcln\"><i class=\"fa-regular fa-circle-check\"></i></span>
                             <span id=\"unoklname\" class=\"status unok-r hcln\"><i class=\"fa-regular fa-circle-xmark\"></i></span>
                             <span id=\"hintln\" class=\"hint-css\"></span>
                            <input type=\"text\" name=\"lname\" class=\"form-control\" id=\"lnameVal\" value=\"{{profile.lastname}}\" placeholder=\"surname\">
                        </div>
                    </div>


                    <div class=\"row mt-3\">
                        <div class=\"col-md-12\">
                            <label class=\"labels\">Email ID:</label>
                            <span class=\"error req-fd\" id=\"emailHint\">*</span>
                            <span id=\"okmail\" class=\"status ok-g hcm\"><i class=\"fa-regular fa-circle-check\"></i></span>
                            <span id=\"unokmail\" class=\"status unok-r hcm\"><i class=\"fa-regular fa-circle-xmark\"></i></span>
                            <span id=\"hintm\" class=\"hint-css\"></span>
                            <input type=\"text\" name=\"email\" class=\"form-control\" id=\"emailVal\" placeholder=\"enter email id\" value=\"{{profile.email}}\">
                        </div>


                        <div class=\"col-md-12\">
                            <label class=\"labels\">Mobile Number:</label>
                            <span class=\"error req-fd\" id=\"phnHint\">*</span>
                            <span id=\"okphn\" class=\"status ok-g hcph\"><i class=\"fa-regular fa-circle-check\"></i></span>
                           <span id=\"unokphn\" class=\"status unok-r hcph\"><i class=\"fa-regular fa-circle-xmark\"></i></span>
                           <span id=\"hintphn\" class=\"hint-css\"></span>
                            <input type=\"text\" name=\"phone\" class=\"form-control\" id=\"phnVal\" placeholder=\"enter phone number\" value=\"{{profile.phone}}\">
                        </div>
                        
                        
                        
                        <div class=\"col-md-12\">
                            <label class=\"labels\">User Address:</label>
                            <span class=\"error req-fd\" id=\"titleHint\">*</span>
                           <span id=\"okadd\" class=\"status ok-g hadd\"><i class=\"fa-regular fa-circle-check\"></i></span>
                           <span id=\"unokadd\" class=\"status unok-r hadd\"><i class=\"fa-regular fa-circle-xmark\"></i></span>
                            <span id=\"hintadd\" class=\"hint-css-p\"></span>
                            <input type=\"text\" name=\"address\" class=\"form-control\" id=\"haddress\" placeholder=\"enter address \" value=\"{{profile.address}}\">
                        </div>
                        
                        
                        <div class=\"col-md-12\">
                            <label class=\"labels\">Postcode:</label>
                            <span class=\"error req-fd\" id=\"pinHint\">*</span>
                           <span id=\"okpin\" class=\"status ok-g hpin\"><i class=\"fa-regular fa-circle-check\"></i></span>
                           <span id=\"unokpin\" class=\"status unok-r hpin\"><i class=\"fa-regular fa-circle-xmark\"></i></span>
                           <span id=\"hintpin\" class=\"hint-css\"></span>
                            <input type=\"text\" name=\"pincode\" id=\"pinVal\" class=\"form-control\" placeholder=\"enter pincode\" value=\"{{profile.pincode}}\">
                        </div>
                        
                        <div class=\"col-md-12\">
                            <label class=\"labels\">State:</label><input type=\"text\" name=\"state\" class=\"form-control\" placeholder=\"state\" value=\"{{profile.state}}\">
                        </div>


                    </div>
                    <div class=\"row mt-3\">
                        <div class=\"col-md-6\"><label class=\"labels\">Country</label><input name=\"country\" type=\"text\" class=\"form-control\" placeholder=\"country\" value=\"{{profile.country}}\"></div>
                        <div class=\"col-md-6\"><label class=\"labels\">State/Region</label><input name=\"city\" type=\"text\" class=\"form-control\" value=\"{{profile.city}}\" placeholder=\"city\"></div>
                    </div>
                    <div class=\"row mt-3\">
                        <div class=\"col-md-12\"><label class=\"labels\">Gender:</label><input type=\"text\" name=\"gender\" class=\"form-control\" placeholder=\"gender\" value=\"{{profile.gender}}\" ></div>                   
                    </div>

                    <div class=\"mt-4 text-center\"><input type=\"submit\" name=\"submit\" value=\"Save Profile\" class=\"btn btn-primary profile-button\" onclick=\"return cnfRgr()\"></div>

                </div>
            </div>

 

            <div class=\"col-md-4 mt-3\">
                <a href=\"{{path('logout')}}\"><input type=\"button\" name=\"submit\"  value=\"LOGOUT\" class=\"preview\" onclick=\"return logout()\"></a>
               
                <div class=\"p-3 py-5 \">
                   <div class=\"col-md-12\">
                            <label class=\"labels\">About Mr. {{profile.firstname}}:</label>
                            <span class=\"error req-fd\" id=\"titleHint\">*</span>
                           <span id=\"okabout\" class=\"status ok-g habt\"><i class=\"fa-regular fa-circle-check\"></i></span>
                          <span id=\"unokabout\" class=\"status unok-r habt\"><i class=\"fa-regular fa-circle-xmark\"></i></span>
                            <span id=\"hintabout\" class=\"hint-css-p\"></span>
                            <input type=\"text\" name=\"about\" class=\"form-control\" id=\"habout\"  placeholder=\"about your self\" value=\"{{profile.about}}\">
                    </div> 
                    <br>

                    <div class=\"form-content\">
                        <label for=\"fileToUpload\" class=\"up-img\">Upload Image</label>
                         <input type=\"file\" name=\"fileToUpload\" id=\"fileToUpload\" value={{profile.url}} class=\"upload-img bg-success\" >   <br>
                         <span class=\"error req-fd req-txt\" id=\"imgHint\">*IMG Size less than 500KB and Ext: jpg, png, jpeg
                         </span><br>
                         <span id=\"okimg\" class=\"status ok-g himg\"><i class=\"fa-regular fa-circle-check\"></i></span>
                         <span id=\"unokimg\" class=\"status unok-r himg\"><i class=\"fa-regular fa-circle-xmark\"></i></span>
                         <span id=\"hintimg\" class=\"hint-css-p\"></span>       
                    </div>

                </div>

            </div>

        </div>
    </div>
    </div>
    </div>
</form>




<div class=\"container-fluid p-0 mt-5\">

  <footer class=\"bg-dark text-center text-white pt-5\">
  <div class=\"container p-4 pb-0\">
    <section class=\"mb-4\">
      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-facebook-f\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-twitter\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-google\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-instagram\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-linkedin-in\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-github\"></i></a>
    </section>
  </div>

  <div class=\"text-center p-3\" style=\"background-color: rgba(0, 0, 0, 0.2);\">
    © 2020 Copyright:
    <a class=\"text-white\" href=\"https://webkul.com/\">webkul.com</a>
  </div>
</footer>
  
</div>


{% endblock %}", "view/profileEdit.html.twig", "/home/users/shivam.baranwal/www/html/symfony_4/templates/view/profileEdit.html.twig");
    }
}
