<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* view/editActivePost.html.twig */
class __TwigTemplate_58b7798287484926fd03bf297ee0a59cafcd52fbb5c3164cf505008d5884ad33 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'stylesheets' => [$this, 'block_stylesheets'],
            'javascripts' => [$this, 'block_javascripts'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "view/editActivePost.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "view/editActivePost.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "view/editActivePost.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 2
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "Login Form";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 3
    public function block_stylesheets($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 4
        echo "        <link href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css\" rel=\"stylesheet\"integrity=\"sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN\" crossorigin=\"anonymous\">
        <link rel=\"stylesheet\" href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-alpha1/dist/css/bootstrap.min.css\">
        <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css\"integrity=\"sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==\"crossorigin=\"anonymous\" referrerpolicy=\"no-referrer\" />
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 9
    public function block_javascripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        // line 10
        echo "        <script src=\"https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js\"integrity=\"sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL\"crossorigin=\"anonymous\"></script>
        <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js\"></script>
        <script src=\"https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js\"></script>
        <script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js\"></script>
        <script src=\"https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-alpha1/dist/js/bootstrap.bundle.min.js\"></script>    
        <script src=\"https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js\"></script>
        <script src=\"";
        // line 16
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/editJob.js"), "html", null, true);
        echo "\"></script>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 19
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 20
        echo "<link href=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("css/createJob.css"), "html", null, true);
        echo "\" rel=\"stylesheet\"/>

    <div class=\"container-fluid bg-muted p-0\">
        <div class=\"row m-0\">
            <div class=\"col-lg-12 p-0\">
                <nav class=\"navbar nav1 \">  
                    <div class=\"div1\">
                        <div class=\"child1 m-0\">
                            <a class=\"navbar-brand\" href=\"#\">
                                <img src=\"";
        // line 29
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/nav_logo.png"), "html", null, true);
        echo "\" width=\"250\" height=\"70\" class=\"d-inline-block img align-top\"
                                    alt=\"\">
                            </a>
                        </div>

                        <div class=\"child2\">
                        <a href=\"";
        // line 35
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("viewActivePost", ["mail" => twig_get_attribute($this->env, $this->source, (isset($context["job"]) || array_key_exists("job", $context) ? $context["job"] : (function () { throw new RuntimeError('Variable "job" does not exist.', 35, $this->source); })()), "email", [], "any", false, false, false, 35)]), "html", null, true);
        echo "\" class=\"link1\">Back</a>
                        <a href=\"";
        // line 36
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("logout");
        echo "\" class=\"link1\" onclick=\"return logout()\">Logout</a>
                        </div>
                    </div>
                </nav>
            </div>
        </div>


        <div class=\"div2 p-3\">
            <div class=\"child3\">
            <h3 class=\"head1\">Edit JOB</h3>
            </div>
            <p><span class=\"error req-fd\">* required field</span></p>
            <form method=\"post\" action=\"";
        // line 49
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("updateActivejob", ["id" => twig_get_attribute($this->env, $this->source, (isset($context["job"]) || array_key_exists("job", $context) ? $context["job"] : (function () { throw new RuntimeError('Variable "job" does not exist.', 49, $this->source); })()), "id", [], "any", false, false, false, 49)]), "html", null, true);
        echo "\" enctype=\"multipart/form-data\" onsubmit=\"return cnfForm()\">
                
            <div class=\"form-content\">
                   <span class=\"para1\">Name:</span> 
                   <span class=\"error req-fd\" id=\"nameHint\">*
                    </span>
                    <span id=\"okname\" class=\"status ok-g hcn\"><i class=\"fa-regular fa-circle-check\"></i></span>
                    <span id=\"unokname\" class=\"status unok-r hcn\"><i class=\"fa-regular fa-circle-xmark\"></i></span>
                    <span id=\"hintn\" class=\"hint-css\"></span>
                <br><input type=\"text\" name=\"name\" value=\"";
        // line 58
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["job"]) || array_key_exists("job", $context) ? $context["job"] : (function () { throw new RuntimeError('Variable "job" does not exist.', 58, $this->source); })()), "name", [], "any", false, false, false, 58), "html", null, true);
        echo "\" class=\"inp\" id=\"nameVal\">               
                <br>
            </div>
            

            <div class=\"form-content\">
                   <span class=\"para1\" >E-mail:</span> 
                   <span class=\"error req-fd\" id=\"mailErr\">*
                    </span>
                    <span id=\"okmail\" class=\"status ok-g hcm\"><i class=\"fa-regular fa-circle-check\"></i></span>
                    <span id=\"unokmail\" class=\"status unok-r hcm\"><i class=\"fa-regular fa-circle-xmark\"></i></span>
                    <span id=\"hintm\" class=\"hint-css\"></span>
                <br><input type=\"text\" name=\"email\" value=";
        // line 70
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["job"]) || array_key_exists("job", $context) ? $context["job"] : (function () { throw new RuntimeError('Variable "job" does not exist.', 70, $this->source); })()), "email", [], "any", false, false, false, 70), "html", null, true);
        echo " class=\"inp\" id=\"emailVal\" >              
                <br>
            </div>

            <div class=\"form-content\">
            <span class=\"para1\" >Location:</span> 
                <span class=\"error req-fd\" id=\"locationHint\">*</span>
                <span id=\"oklocation\" class=\"status ok-g hloc\"><i class=\"fa-regular fa-circle-check\"></i></span>
                <span id=\"unoklocation\" class=\"status unok-r hloc\"><i class=\"fa-regular fa-circle-xmark\"></i></span>
                <span id=\"hintloc\" class=\"hint-css\"></span>
                <br><input type=\"text\" name=\"location\" value=\"";
        // line 80
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["job"]) || array_key_exists("job", $context) ? $context["job"] : (function () { throw new RuntimeError('Variable "job" does not exist.', 80, $this->source); })()), "location", [], "any", false, false, false, 80), "html", null, true);
        echo "\" class=\"inp\" id=\"locVal\">
                <br>
            </div>

            <div class=\"form-content\">
            <span class=\"para1\" >Job Title:</span> 
               <span class=\"error req-fd\" id=\"titleHint\">*
                </span>
                <span id=\"oktitle\" class=\"status ok-g htitle\"><i class=\"fa-regular fa-circle-check\"></i></span>
                <span id=\"unoktitle\" class=\"status unok-r htitle\"><i class=\"fa-regular fa-circle-xmark\"></i></span>
                <span id=\"hinttitle\" class=\"hint-css\"></span>
                <br><textarea name=\"title\" rows=\"5\" cols=\"40\" class=\"inp1\" id=\"titleVal\">";
        // line 91
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["job"]) || array_key_exists("job", $context) ? $context["job"] : (function () { throw new RuntimeError('Variable "job" does not exist.', 91, $this->source); })()), "title", [], "any", false, false, false, 91), "html", null, true);
        echo "</textarea>
                <br>
            </div>
            

            <div class=\"form-content\">
                    <label for=\"fileToUpload\" class=\"up-img\">Upload Image</label>
                         <input type=\"file\" name=\"fileToUpload\" id=\"fileToUpload\" value=";
        // line 98
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["job"]) || array_key_exists("job", $context) ? $context["job"] : (function () { throw new RuntimeError('Variable "job" does not exist.', 98, $this->source); })()), "url", [], "any", false, false, false, 98), "html", null, true);
        echo " class=\"upload-img bg-success\"  >   
                         <span class=\"error req-fd\" id=\"imgHint\">*</span>
                         <span id=\"okimg\" class=\"status ok-g himg\"><i class=\"fa-regular fa-circle-check\"></i></span>
                         <span id=\"unokimg\" class=\"status unok-r himg\"><i class=\"fa-regular fa-circle-xmark\"></i></span>
                         <span id=\"hintimg\" class=\"hint-css-p\"></span>       
                </div>
            

            <div class=\"form-content\">
                <input type=\"submit\" name=\"submit\" value=\"preview post\" class=\"preview \">
            </div>
            </form>
        </div>
    </div>


<div class=\"container-fluid p-0 mt-5\">

  <footer class=\"bg-dark text-center text-white pt-5\">
  <div class=\"container p-4 pb-0\">
    <section class=\"mb-4\">
      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-facebook-f\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-twitter\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-google\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-instagram\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-linkedin-in\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-github\"></i></a>
    </section>
  </div>

  <div class=\"text-center p-3\" style=\"background-color: rgba(0, 0, 0, 0.2);\">
    © 2020 Copyright:
    <a class=\"text-white\" href=\"https://webkul.com/\">webkul.com</a>
  </div>
</footer>
  
</div>




";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "view/editActivePost.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable()
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  250 => 98,  240 => 91,  226 => 80,  213 => 70,  198 => 58,  186 => 49,  170 => 36,  166 => 35,  157 => 29,  144 => 20,  134 => 19,  121 => 16,  113 => 10,  103 => 9,  90 => 4,  80 => 3,  61 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}
{% block title %}Login Form{% endblock %}
{% block stylesheets %}
        <link href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css\" rel=\"stylesheet\"integrity=\"sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN\" crossorigin=\"anonymous\">
        <link rel=\"stylesheet\" href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-alpha1/dist/css/bootstrap.min.css\">
        <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css\"integrity=\"sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==\"crossorigin=\"anonymous\" referrerpolicy=\"no-referrer\" />
{% endblock %}

{% block javascripts %}
        <script src=\"https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js\"integrity=\"sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL\"crossorigin=\"anonymous\"></script>
        <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js\"></script>
        <script src=\"https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js\"></script>
        <script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js\"></script>
        <script src=\"https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-alpha1/dist/js/bootstrap.bundle.min.js\"></script>    
        <script src=\"https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js\"></script>
        <script src=\"{{ asset('js/editJob.js') }}\"></script>

{% endblock %}
{% block body %}
<link href=\"{{ asset('css/createJob.css') }}\" rel=\"stylesheet\"/>

    <div class=\"container-fluid bg-muted p-0\">
        <div class=\"row m-0\">
            <div class=\"col-lg-12 p-0\">
                <nav class=\"navbar nav1 \">  
                    <div class=\"div1\">
                        <div class=\"child1 m-0\">
                            <a class=\"navbar-brand\" href=\"#\">
                                <img src=\"{{ asset('img/nav_logo.png') }}\" width=\"250\" height=\"70\" class=\"d-inline-block img align-top\"
                                    alt=\"\">
                            </a>
                        </div>

                        <div class=\"child2\">
                        <a href=\"{{path('viewActivePost',{'mail': job.email })}}\" class=\"link1\">Back</a>
                        <a href=\"{{path('logout')}}\" class=\"link1\" onclick=\"return logout()\">Logout</a>
                        </div>
                    </div>
                </nav>
            </div>
        </div>


        <div class=\"div2 p-3\">
            <div class=\"child3\">
            <h3 class=\"head1\">Edit JOB</h3>
            </div>
            <p><span class=\"error req-fd\">* required field</span></p>
            <form method=\"post\" action=\"{{path('updateActivejob',{'id': job.id})}}\" enctype=\"multipart/form-data\" onsubmit=\"return cnfForm()\">
                
            <div class=\"form-content\">
                   <span class=\"para1\">Name:</span> 
                   <span class=\"error req-fd\" id=\"nameHint\">*
                    </span>
                    <span id=\"okname\" class=\"status ok-g hcn\"><i class=\"fa-regular fa-circle-check\"></i></span>
                    <span id=\"unokname\" class=\"status unok-r hcn\"><i class=\"fa-regular fa-circle-xmark\"></i></span>
                    <span id=\"hintn\" class=\"hint-css\"></span>
                <br><input type=\"text\" name=\"name\" value=\"{{job.name}}\" class=\"inp\" id=\"nameVal\">               
                <br>
            </div>
            

            <div class=\"form-content\">
                   <span class=\"para1\" >E-mail:</span> 
                   <span class=\"error req-fd\" id=\"mailErr\">*
                    </span>
                    <span id=\"okmail\" class=\"status ok-g hcm\"><i class=\"fa-regular fa-circle-check\"></i></span>
                    <span id=\"unokmail\" class=\"status unok-r hcm\"><i class=\"fa-regular fa-circle-xmark\"></i></span>
                    <span id=\"hintm\" class=\"hint-css\"></span>
                <br><input type=\"text\" name=\"email\" value={{job.email}} class=\"inp\" id=\"emailVal\" >              
                <br>
            </div>

            <div class=\"form-content\">
            <span class=\"para1\" >Location:</span> 
                <span class=\"error req-fd\" id=\"locationHint\">*</span>
                <span id=\"oklocation\" class=\"status ok-g hloc\"><i class=\"fa-regular fa-circle-check\"></i></span>
                <span id=\"unoklocation\" class=\"status unok-r hloc\"><i class=\"fa-regular fa-circle-xmark\"></i></span>
                <span id=\"hintloc\" class=\"hint-css\"></span>
                <br><input type=\"text\" name=\"location\" value=\"{{job.location}}\" class=\"inp\" id=\"locVal\">
                <br>
            </div>

            <div class=\"form-content\">
            <span class=\"para1\" >Job Title:</span> 
               <span class=\"error req-fd\" id=\"titleHint\">*
                </span>
                <span id=\"oktitle\" class=\"status ok-g htitle\"><i class=\"fa-regular fa-circle-check\"></i></span>
                <span id=\"unoktitle\" class=\"status unok-r htitle\"><i class=\"fa-regular fa-circle-xmark\"></i></span>
                <span id=\"hinttitle\" class=\"hint-css\"></span>
                <br><textarea name=\"title\" rows=\"5\" cols=\"40\" class=\"inp1\" id=\"titleVal\">{{job.title}}</textarea>
                <br>
            </div>
            

            <div class=\"form-content\">
                    <label for=\"fileToUpload\" class=\"up-img\">Upload Image</label>
                         <input type=\"file\" name=\"fileToUpload\" id=\"fileToUpload\" value={{job.url}} class=\"upload-img bg-success\"  >   
                         <span class=\"error req-fd\" id=\"imgHint\">*</span>
                         <span id=\"okimg\" class=\"status ok-g himg\"><i class=\"fa-regular fa-circle-check\"></i></span>
                         <span id=\"unokimg\" class=\"status unok-r himg\"><i class=\"fa-regular fa-circle-xmark\"></i></span>
                         <span id=\"hintimg\" class=\"hint-css-p\"></span>       
                </div>
            

            <div class=\"form-content\">
                <input type=\"submit\" name=\"submit\" value=\"preview post\" class=\"preview \">
            </div>
            </form>
        </div>
    </div>


<div class=\"container-fluid p-0 mt-5\">

  <footer class=\"bg-dark text-center text-white pt-5\">
  <div class=\"container p-4 pb-0\">
    <section class=\"mb-4\">
      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-facebook-f\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-twitter\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-google\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-instagram\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-linkedin-in\"></i></a>

      <a class=\"btn btn-outline-light btn-floating m-1\" href=\"#!\" role=\"button\"><i class=\"fab fa-github\"></i></a>
    </section>
  </div>

  <div class=\"text-center p-3\" style=\"background-color: rgba(0, 0, 0, 0.2);\">
    © 2020 Copyright:
    <a class=\"text-white\" href=\"https://webkul.com/\">webkul.com</a>
  </div>
</footer>
  
</div>




{% endblock %}", "view/editActivePost.html.twig", "/home/users/shivam.baranwal/www/html/symfony_4/templates/view/editActivePost.html.twig");
    }
}
