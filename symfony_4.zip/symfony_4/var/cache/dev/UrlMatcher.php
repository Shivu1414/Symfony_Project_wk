<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/_profiler' => [[['_route' => '_profiler_home', '_controller' => 'web_profiler.controller.profiler::homeAction'], null, null, null, true, false, null]],
        '/_profiler/search' => [[['_route' => '_profiler_search', '_controller' => 'web_profiler.controller.profiler::searchAction'], null, null, null, false, false, null]],
        '/_profiler/search_bar' => [[['_route' => '_profiler_search_bar', '_controller' => 'web_profiler.controller.profiler::searchBarAction'], null, null, null, false, false, null]],
        '/_profiler/phpinfo' => [[['_route' => '_profiler_phpinfo', '_controller' => 'web_profiler.controller.profiler::phpinfoAction'], null, null, null, false, false, null]],
        '/_profiler/open' => [[['_route' => '_profiler_open_file', '_controller' => 'web_profiler.controller.profiler::openAction'], null, null, null, false, false, null]],
        '/admin_signdata' => [[['_route' => 'admin_signdata', '_controller' => 'App\\Controller\\AdminSignupController::createSign'], null, null, null, false, false, null]],
        '/login' => [[['_route' => 'app_login', '_controller' => 'App\\Controller\\AuthController::login'], null, null, null, false, false, null]],
        '/logdata' => [[['_route' => 'logdata', '_controller' => 'App\\Controller\\LogController::createLogin'], null, null, null, false, false, null]],
        '/alldeladmin' => [[['_route' => 'alldeladmin', '_controller' => 'App\\Controller\\LogController::allDelAdmin'], null, null, null, false, false, null]],
        '/multidelUser' => [[['_route' => 'multidelUser', '_controller' => 'App\\Controller\\LogController::multiDelUser'], null, null, null, false, false, null]],
        '/logout' => [[['_route' => 'logout', '_controller' => 'App\\Controller\\LogController::logout'], null, null, null, false, false, null]],
        '/' => [[['_route' => 'login', '_controller' => 'App\\Controller\\LoginController::index'], null, null, null, false, false, null]],
        '/signup' => [[['_route' => 'signup', '_controller' => 'App\\Controller\\LoginController::register'], null, null, null, false, false, null]],
        '/Admin' => [[['_route' => 'admin', '_controller' => 'App\\Controller\\LoginController::aRegister'], null, null, null, false, false, null]],
        '/blogdata' => [[['_route' => 'blogdata', '_controller' => 'App\\Controller\\UnpostedJobController::blogData'], null, null, null, false, false, null]],
        '/signdata' => [[['_route' => 'signdata', '_controller' => 'App\\Controller\\UserSignupController::createSign'], null, null, null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/_(?'
                    .'|error/(\\d+)(?:\\.([^/]++))?(*:38)'
                    .'|wdt/([^/]++)(*:57)'
                    .'|profiler/([^/]++)(?'
                        .'|/(?'
                            .'|search/results(*:102)'
                            .'|router(*:116)'
                            .'|exception(?'
                                .'|(*:136)'
                                .'|\\.css(*:149)'
                            .')'
                        .')'
                        .'|(*:159)'
                    .')'
                .')'
                .'|/p(?'
                    .'|rofile_edit/([^/]++)(*:194)'
                    .'|ub(?'
                        .'|lish(?'
                            .'|/([^/]++)(?:/([^/]++))?(*:237)'
                            .'|data/([^/]++)/([^/]++)(*:267)'
                        .')'
                        .'|data/([^/]++)/([^/]++)(*:298)'
                    .')'
                .')'
                .'|/a(?'
                    .'|ctive(?'
                        .'|post/([^/]++)(*:334)'
                        .'|PublishPost/([^/]++)(*:362)'
                    .')'
                    .'|dminProfile(?:/([^/]++))?(*:396)'
                    .'|ll(?'
                        .'|del(?'
                            .'|unpub/([^/]++)(*:429)'
                            .'|ActiveData/([^/]++)(*:456)'
                            .'|PubActiveData/([^/]++)(*:486)'
                        .')'
                        .'|Postsrch/([^/]++)(?:/([^/]++))?(*:526)'
                    .')'
                    .'|user(?'
                        .'|Pub/([^/]++)/([^/]++)(*:563)'
                        .'|Unpub/([^/]++)/([^/]++)(*:594)'
                    .')'
                .')'
                .'|/u(?'
                    .'|ser(?'
                        .'|p(?'
                            .'|rofile/([^/]++)(*:634)'
                            .'|ostview/([^/]++)/([^/]++)/([^/]++)/([^/]++)/([^/]++)/([^/]++)(*:703)'
                        .')'
                        .'|allpost/([^/]++)(?:/([^/]++)(?:/([^/]++)(?:/([^/]++))?)?)?(*:770)'
                    .')'
                    .'|npub(?'
                        .'|lish/([^/]++)(*:799)'
                        .'|data/([^/]++)/([^/]++)(*:829)'
                    .')'
                    .'|pdate(?'
                        .'|postjob/([^/]++)(*:862)'
                        .'|job/([^/]++)(*:882)'
                        .'|Active(?'
                            .'|job/([^/]++)(*:911)'
                            .'|Pubjob/([^/]++)(*:934)'
                        .')'
                    .')'
                .')'
                .'|/del(?'
                    .'|pub(?'
                        .'|lish/([^/]++)/([^/]++)(*:980)'
                        .'|post/([^/]++)/([^/]++)(*:1010)'
                    .')'
                    .'|unpub(?'
                        .'|lish/([^/]++)/([^/]++)(*:1050)'
                        .'|post/([^/]++)/([^/]++)(*:1081)'
                    .')'
                    .'|Active(?'
                        .'|Data/([^/]++)/([^/]++)(*:1122)'
                        .'|PubData/([^/]++)/([^/]++)(*:1156)'
                    .')'
                .')'
                .'|/search/([^/]++)(*:1183)'
                .'|/view(?'
                    .'|publishPost/([^/]++)(?:/([^/]++))?(*:1234)'
                    .'|ActivePost/([^/]++)(?:/([^/]++))?(*:1276)'
                .')'
                .'|/blog/([^/]++)(*:1300)'
                .'|/jobdata/([^/]++)(?:/([^/]++))?(*:1340)'
                .'|/edit(?'
                    .'|job/([^/]++)/([^/]++)(*:1378)'
                    .'|unpostjob/([^/]++)/([^/]++)(*:1414)'
                    .'|postjob/([^/]++)/([^/]++)(*:1448)'
                    .'|ActiveP(?'
                        .'|ost/([^/]++)/([^/]++)(*:1488)'
                        .'|ubPost/([^/]++)/([^/]++)(*:1521)'
                    .')'
                .')'
                .'|/mul(?'
                    .'|tidel(?'
                        .'|/([^/]++)(*:1556)'
                        .'|APosts/([^/]++)/([^/]++)(*:1589)'
                    .')'
                    .'|delActive(?'
                        .'|Data/([^/]++)(*:1624)'
                        .'|PubData/([^/]++)(*:1649)'
                    .')'
                .')'
                .'|/EditProfileData/([^/]++)(*:1685)'
            .')/?$}sD',
    ],
    [ // $dynamicRoutes
        38 => [[['_route' => '_preview_error', '_controller' => 'error_controller::preview', '_format' => 'html'], ['code', '_format'], null, null, false, true, null]],
        57 => [[['_route' => '_wdt', '_controller' => 'web_profiler.controller.profiler::toolbarAction'], ['token'], null, null, false, true, null]],
        102 => [[['_route' => '_profiler_search_results', '_controller' => 'web_profiler.controller.profiler::searchResultsAction'], ['token'], null, null, false, false, null]],
        116 => [[['_route' => '_profiler_router', '_controller' => 'web_profiler.controller.router::panelAction'], ['token'], null, null, false, false, null]],
        136 => [[['_route' => '_profiler_exception', '_controller' => 'web_profiler.controller.exception_panel::body'], ['token'], null, null, false, false, null]],
        149 => [[['_route' => '_profiler_exception_css', '_controller' => 'web_profiler.controller.exception_panel::stylesheet'], ['token'], null, null, false, false, null]],
        159 => [[['_route' => '_profiler', '_controller' => 'web_profiler.controller.profiler::panelAction'], ['token'], null, null, false, true, null]],
        194 => [[['_route' => 'profile_edit', '_controller' => 'App\\Controller\\LogController::profileEdit'], ['mail'], null, null, false, true, null]],
        237 => [[['_route' => 'publish', 'page' => '1', '_controller' => 'App\\Controller\\PublishedJobController::publishedJob'], ['mail', 'page'], null, null, false, true, null]],
        267 => [[['_route' => 'publishdata', '_controller' => 'App\\Controller\\UnpostedJobController::publishData'], ['id', 'mail'], null, null, false, true, null]],
        298 => [[['_route' => 'pubdata', '_controller' => 'App\\Controller\\UserAllPostController::pubData'], ['id', 'mail'], null, null, false, true, null]],
        334 => [[['_route' => 'activepost', '_controller' => 'App\\Controller\\LogController::checkActivePost'], ['mail'], null, null, false, true, null]],
        362 => [[['_route' => 'activePublishPost', '_controller' => 'App\\Controller\\LogController::activePublishPost'], ['mail'], null, null, false, true, null]],
        396 => [[['_route' => 'adminProfile', 'page' => '1', '_controller' => 'App\\Controller\\LogController::adminprofile'], ['page'], null, null, false, true, null]],
        429 => [[['_route' => 'alldelunpub', '_controller' => 'App\\Controller\\UnpostedJobController::allDelUnpublish'], ['mail'], null, null, false, true, null]],
        456 => [[['_route' => 'alldelActiveData', '_controller' => 'App\\Controller\\UnpostedJobController::allDelActiveData'], ['mail'], null, null, false, true, null]],
        486 => [[['_route' => 'alldelPubActiveData', '_controller' => 'App\\Controller\\UserIconApageController::alldelPubActiveData'], ['mail'], null, null, false, true, null]],
        526 => [[['_route' => 'allPostsrch', 'val' => '1', 'page' => '1', 'tag' => 0, '_controller' => 'App\\Controller\\UserAllPostController::allPostsrch'], ['mail', 'val'], null, null, false, true, null]],
        563 => [[['_route' => 'auserPub', '_controller' => 'App\\Controller\\UserIconApageController::aUserPub'], ['mail', 'id'], null, null, false, true, null]],
        594 => [[['_route' => 'auserUnpub', '_controller' => 'App\\Controller\\UserIconApageController::auserUnpub'], ['mail', 'id'], null, null, false, true, null]],
        634 => [[['_route' => 'userprofile', '_controller' => 'App\\Controller\\LogController::userprofile'], ['mail'], null, null, false, true, null]],
        703 => [[['_route' => 'userpostview', 'val' => '1', 'page' => '1', 'tag' => 0, '_controller' => 'App\\Controller\\UserAllPostController::userpostView'], ['mail', 'val', 'id', 'page', 'tag', 'pg'], null, null, false, true, null]],
        770 => [[['_route' => 'userallpost', 'val' => '1', 'page' => '1', 'tag' => 0, 'pg' => 1, '_controller' => 'App\\Controller\\UserAllPostController::userAllPosts'], ['mail', 'val', 'page', 'pg'], null, null, false, true, null]],
        799 => [[['_route' => 'unpublish', '_controller' => 'App\\Controller\\PublishedJobController::unpublishJob'], ['mail'], null, null, false, true, null]],
        829 => [[['_route' => 'unpubdata', '_controller' => 'App\\Controller\\UserAllPostController::unpubData'], ['id', 'mail'], null, null, false, true, null]],
        862 => [[['_route' => 'updatepostjob', '_controller' => 'App\\Controller\\PublishedJobController::updatepostjob'], ['id'], null, null, false, true, null]],
        882 => [[['_route' => 'updatejob', '_controller' => 'App\\Controller\\UnpostedJobController::updateJob'], ['id'], null, null, false, true, null]],
        911 => [[['_route' => 'updateActivejob', '_controller' => 'App\\Controller\\UserIconApageController::updateActivejob'], ['id'], null, null, false, true, null]],
        934 => [[['_route' => 'updateActivePubjob', '_controller' => 'App\\Controller\\UserIconApageController::updateActivePubjob'], ['id'], null, null, false, true, null]],
        980 => [[['_route' => 'delpublish', '_controller' => 'App\\Controller\\PublishedJobController::delPublishJob'], ['mail', 'id'], null, null, false, true, null]],
        1010 => [[['_route' => 'delpubpost', '_controller' => 'App\\Controller\\UserAllPostController::delpubpost'], ['mail', 'id'], null, null, false, true, null]],
        1050 => [[['_route' => 'delunpublish', '_controller' => 'App\\Controller\\UnpostedJobController::delUnpublishJob'], ['mail', 'id'], null, null, false, true, null]],
        1081 => [[['_route' => 'delunpubpost', '_controller' => 'App\\Controller\\UserAllPostController::delunpubpost'], ['mail', 'id'], null, null, false, true, null]],
        1122 => [[['_route' => 'delActiveData', '_controller' => 'App\\Controller\\UnpostedJobController::delactivedata'], ['mail', 'id'], null, null, false, true, null]],
        1156 => [[['_route' => 'delActivePubData', '_controller' => 'App\\Controller\\UserIconApageController::delActivePubData'], ['mail', 'id'], null, null, false, true, null]],
        1183 => [[['_route' => 'search', '_controller' => 'App\\Controller\\PublishedJobController::Search'], ['mail'], null, null, false, true, null]],
        1234 => [[['_route' => 'viewpublishPost', 'page' => '1', '_controller' => 'App\\Controller\\PublishedJobController::viewpublishPost'], ['mail', 'page'], null, null, false, true, null]],
        1276 => [[['_route' => 'viewActivePost', 'page' => '1', '_controller' => 'App\\Controller\\UnpostedJobController::viewActivePost'], ['mail', 'page'], null, null, false, true, null]],
        1300 => [[['_route' => 'blog', '_controller' => 'App\\Controller\\UnpostedJobController::createBlog'], ['mail'], null, null, false, true, null]],
        1340 => [[['_route' => 'jobdata', 'page' => '1', '_controller' => 'App\\Controller\\UnpostedJobController::createdJob'], ['mail', 'page'], null, null, false, true, null]],
        1378 => [[['_route' => 'editjob', '_controller' => 'App\\Controller\\UnpostedJobController::editJob'], ['id', 'mail'], null, null, false, true, null]],
        1414 => [[['_route' => 'editunpostjob', '_controller' => 'App\\Controller\\UserAllPostController::editUnpostjob'], ['id', 'mail'], null, null, false, true, null]],
        1448 => [[['_route' => 'editpostjob', '_controller' => 'App\\Controller\\UserAllPostController::editpostjob'], ['id', 'mail'], null, null, false, true, null]],
        1488 => [[['_route' => 'editActivePost', '_controller' => 'App\\Controller\\UserIconApageController::editActivePost'], ['id', 'mail'], null, null, false, true, null]],
        1521 => [[['_route' => 'editActivePubPost', '_controller' => 'App\\Controller\\UserIconApageController::editActivePubPost'], ['id', 'mail'], null, null, false, true, null]],
        1556 => [[['_route' => 'multidel', '_controller' => 'App\\Controller\\UnpostedJobController::multiDel'], ['mail'], null, null, false, true, null]],
        1589 => [[['_route' => 'multidelAPosts', '_controller' => 'App\\Controller\\UserAllPostController::multidelAPosts'], ['mail', 'temp'], null, null, false, true, null]],
        1624 => [[['_route' => 'muldelActiveData', '_controller' => 'App\\Controller\\UnpostedJobController::muldelActiveData'], ['mail'], null, null, false, true, null]],
        1649 => [[['_route' => 'muldelActivePubData', '_controller' => 'App\\Controller\\UserIconApageController::muldelActivePubData'], ['mail'], null, null, false, true, null]],
        1685 => [
            [['_route' => 'EditProfileData', '_controller' => 'App\\Controller\\UserSignupController::editProfileData'], ['id'], null, null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
