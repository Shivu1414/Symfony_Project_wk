function cnfDelete(){
    return confirm("Do you really want to Delete it");
}
function logout(){
    return confirm("Do you really want to Logout");
}


